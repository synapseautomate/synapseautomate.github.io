from pathlib import Path
import shutil, sys
payload=Path(__file__).resolve().parents[1]
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
for p in payload.rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(payload)
    if rel.parts and rel.parts[0]=='_release': continue
    d=repo/rel; d.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,d)
print('PASS: vetted payload applied')
