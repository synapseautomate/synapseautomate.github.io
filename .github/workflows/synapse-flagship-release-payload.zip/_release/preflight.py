from pathlib import Path
import hashlib, json, sys
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.')
meta=json.loads((Path(__file__).with_name('baseline.json')).read_text(encoding='utf-8'))
errors=[]
for rel,want in meta['expected'].items():
    p=repo/rel
    if not p.is_file(): errors.append(f'missing guarded file: {rel}'); continue
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got!=want: errors.append(f'snapshot mismatch: {rel} ({got[:12]} != {want[:12]})')
for rel in meta['new_paths']:
    if (repo/rel).exists(): errors.append(f'new-path collision: {rel}')
if errors:
    print('GUARD FAILED - nothing applied')
    for e in errors: print('-',e)
    sys.exit(21)
print('PASS: exact verified baseline')
