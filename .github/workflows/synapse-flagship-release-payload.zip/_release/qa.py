from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import hashlib, json, re, subprocess, sys
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
release=Path(__file__).resolve().parent
errors=[]

def run(cmd):
    print('+',' '.join(cmd)); subprocess.run(cmd,cwd=repo,check=True)
for cmd in [
 ['python3','public-proof/human-approval/validate_rules.py'],
 ['python3','public-proof/structured-extraction-v1/validate.py'],
 ['python3','public-proof/structured-extraction-v1/test_ingest.py'],
 ['python3','public-proof/workflow-output-schema-v2/validate.py'],
 ['python3','public-proof/provenance-50-v1/validate.py'],
 ['python3','public-proof/reliability-regression-v1/run_regression.py','public-proof/reliability-regression-v1/test_cases.csv'],
 ['python3','public-proof/reliability-regression-v1/run_mutation_checks.py','public-proof/reliability-regression-v1/mutation_checks.csv'],
]: run(cmd)

# Exact final payload hash gate.
manifest=json.loads((release/'manifest.json').read_text(encoding='utf-8'))
for rel,want in manifest.items():
    p=repo/rel
    got=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else 'missing'
    if got!=want: errors.append(f'payload hash mismatch: {rel}')

class Parser(HTMLParser):
    def __init__(self): super().__init__(); self.links=[]; self.refs=[]; self.text=[]
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        if tag=='a' and d.get('href'): self.links.append(d['href'])
        for attr in ('href','src'):
            if d.get(attr): self.refs.append(d[attr])
    def handle_data(self,data): self.text.append(data)

public=[
 repo/'rehberler/insan-onayi-escalation-karar-tablosu.html',
 repo/'kanit/ornek-insan-onay-karti.html',
 repo/'rehberler/finans-ai-otomasyonu-guvenli-baslangic.html',
 repo/'araclar/finans-surec-kontrol-listesi.html',
]
for p in public:
    raw=p.read_text(encoding='utf-8'); q=Parser(); q.feed(raw); visible=re.sub(r'\s+',' ',' '.join(q.text))
    if '\ufffd' in raw: errors.append(f'{p.name}: replacement glyph')
    for forbidden in ('Day 12','Gün 12','public proof','ChatGPT','assistant instruction','user instruction','synapseautomate.com'):
        if forbidden.lower() in visible.lower(): errors.append(f'{p.name}: forbidden customer-facing token {forbidden}')
    if 'assets/brand/synapse-logo-clean.png' not in raw: errors.append(f'{p.name}: clean logo missing')
    if not re.search(r'<title>[^<]+</title>',raw,re.I): errors.append(f'{p.name}: title missing')
    if not re.search(r'<meta[^>]+name=["\']description["\'][^>]+>',raw,re.I): errors.append(f'{p.name}: description missing')
    if not re.search(r'<link[^>]+rel=["\']canonical["\'][^>]+>',raw,re.I): errors.append(f'{p.name}: canonical missing')
    for href in q.links:
        h=urlsplit(href)
        if h.scheme in ('http','https','mailto','tel') or href.startswith('#'): continue
        if not h.path: continue
        target=(repo/h.path.lstrip('/')) if h.path.startswith('/') else (p.parent/h.path)
        if not target.exists(): errors.append(f'{p.name}: broken local link {href}')
    for m in re.finditer(r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',raw,re.S|re.I):
        try: data=json.loads(m.group(1))
        except Exception as e: errors.append(f'{p.name}: bad JSON-LD {e}'); continue
        if isinstance(data,dict) and data.get('@type')=='FAQPage':
            for item in data.get('mainEntity',[]):
                qt=re.sub(r'\s+',' ',item.get('name','')).strip(); ans=re.sub(r'\s+',' ',item.get('acceptedAnswer',{}).get('text','')).strip()
                if qt and qt not in visible: errors.append(f'{p.name}: FAQ question not visible: {qt}')
                if ans and ans not in visible: errors.append(f'{p.name}: FAQ answer not visible: {qt}')

decision=(repo/'rehberler/insan-onayi-escalation-karar-tablosu.html').read_text(encoding='utf-8')
for state in ('AUTO_PROCEED','HUMAN_REVIEW','HUMAN_APPROVAL','STOP_ESCALATE'):
    if state not in decision: errors.append('decision table missing '+state)
if len(re.findall(r'<details(?:\s|>)',decision,re.I))!=8: errors.append('decision page visible FAQ count != 8')
guide=(repo/'rehberler/finans-ai-otomasyonu-guvenli-baslangic.html').read_text(encoding='utf-8')
if len(re.findall(r'<details(?:\s|>)',guide,re.I))!=6: errors.append('finance guide visible FAQ count != 6')
for phrase in ('İnsan onayı','Yanlış kesinlik','Kaynak doğrulama'):
    if phrase not in guide: errors.append('finance guide missing '+phrase)
tool=(repo/'araclar/finans-surec-kontrol-listesi.html').read_text(encoding='utf-8')
if len(re.findall(r'type=["\']checkbox["\'][^>]*data-check',tool,re.I))!=8: errors.append('finance checklist controls != 8')
if not ('tavsiye' in tool.lower() and 'vermez' in tool.lower()): errors.append('finance checklist advice boundary missing')
card=(repo/'kanit/ornek-insan-onay-karti.html').read_text(encoding='utf-8')
for token in ('data-act="ONAYLA"','data-act="DÜZENLE"','data-act="REDDET"','data-act="DEVRET"','dış sistem yazımı: kapalı'):
    if token not in card: errors.append('approval card missing '+token)
sm=(repo/'sitemap.xml').read_text(encoding='utf-8'); urls=re.findall(r'<loc>(.*?)</loc>',sm)
if len(urls)!=len(set(urls)): errors.append('duplicate sitemap URLs')
for p in public:
    u='https://synapseautomate.github.io/'+p.relative_to(repo).as_posix()
    if urls.count(u)!=1: errors.append(f'sitemap count for {u} = {urls.count(u)}')
paid=(repo/'surec-analizi.html').read_text(encoding='utf-8'); m=re.search(r'<form\b.*?</form>',paid,re.I|re.S)
if not m: errors.append('Process Analysis form missing')
else:
    required=len(re.findall(r'<(?:input|textarea|select)\b[^>]*\brequired\b',m.group(0),re.I))
    if required>10: errors.append(f'Process Analysis required fields={required} > 10')
timing=(repo/'public-proof/human-approval/time-cost-table.csv').read_text(encoding='utf-8')
if re.search(r',0(?:\.0+)?,.*unmeasured',timing,re.I): errors.append('unmeasured time coerced to zero')
readme=(repo/'public-proof/human-approval/README.md').read_text(encoding='utf-8')
if 'time to approved result' not in readme.lower(): errors.append('approved-result-time metric missing')

# Flagship reputation gate.
pages=[repo/'index.html',repo/'kaynaklar.html',repo/'standards/enterprise-ai-workflow-reliability-standard-2026.html']
for p in pages:
    raw=p.read_text(encoding='utf-8'); q=Parser(); q.feed(raw); visible=' '.join(q.text)
    if '\ufffd' in raw: errors.append(f'bad unicode: {p.name}')
    if not re.search(r'<title>[^<]+</title>',raw,re.I): errors.append(f'missing title: {p.name}')
    if not re.search(r'<meta[^>]+name=["\']description["\'][^>]+>',raw,re.I): errors.append(f'missing description: {p.name}')
    for ref in q.refs:
        if ref.startswith(('#','http://','https://','mailto:','tel:','data:','javascript:')): continue
        path=urlsplit(ref).path
        if not path: continue
        target=(repo/path.lstrip('/')) if path.startswith('/') else (p.parent/path)
        if not target.exists(): errors.append(f'broken local ref {p.name} -> {ref}')
    for bad in ('Day 12','ChatGPT 5.6','100% accurate','guaranteed ROI','NIST approved','ISO certified','OWASP endorsed'):
        if bad.lower() in visible.lower(): errors.append(f'forbidden public wording {bad}: {p.name}')
std=(repo/'standards/enterprise-ai-workflow-reliability-standard-2026.html').read_text(encoding='utf-8')
for token in ('AUTO_PROCEED','HUMAN_REVIEW','HUMAN_APPROVAL','STOP_ESCALATE','R10','Not a certification claim','100/100','50/50','Download the 8-page standard'):
    if token not in std: errors.append('standard missing '+token)
try: json.loads((repo/'public-proof/enterprise-reliability-standard-2026/evidence-map.json').read_text(encoding='utf-8'))
except Exception as e: errors.append('bad evidence map: '+str(e))
pdf=repo/'assets/reports/Synapse_Enterprise_AI_Workflow_Reliability_Standard_2026.pdf'
if not pdf.is_file() or pdf.stat().st_size<150000 or not pdf.read_bytes().startswith(b'%PDF-'): errors.append('standard PDF failed binary sanity gate')
canon='https://synapseautomate.github.io/standards/enterprise-ai-workflow-reliability-standard-2026.html'
if sm.count(canon)!=1: errors.append('flagship sitemap canonical count != 1')

# Secret-like scan on release files.
secret=re.compile(r'ghp_[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{20,}|BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY|sk-[A-Za-z0-9]{20,}')
for rel in manifest:
    p=repo/rel
    if p.suffix.lower() in {'.html','.md','.txt','.csv','.json','.py'}:
        try: txt=p.read_text(encoding='utf-8')
        except Exception: continue
        if secret.search(txt): errors.append('secret-like token found: '+rel)
if errors:
    print('QA FAIL')
    for e in errors: print('-',e)
    sys.exit(34)
print('PASS: all Day 12 + flagship tests, hashes, links, claims, schema, trust and secret gates')
