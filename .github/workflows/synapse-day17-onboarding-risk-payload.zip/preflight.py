from pathlib import Path
import sys
root=Path(sys.argv[1])
need=['index.html','surec-analizi.html','gizlilik.html','assets/js/synapse-measurement-v1.js','pilot/kontrollu-ai-is-akisi-pilotu.html']
missing=[x for x in need if not (root/x).exists()]
if missing:
    raise SystemExit('DAY17 PREFLIGHT FAIL missing: '+', '.join(missing))
print('DAY17 PREFLIGHT PASS')
