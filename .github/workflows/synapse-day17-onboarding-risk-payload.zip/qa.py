from pathlib import Path
import sys,json,csv,re,subprocess
root=Path(sys.argv[1])
new=['araclar/otomasyon-hata-maliyeti-hesaplayici.html', 'pilot/pilot-onboarding.html', 'kanit/pilot-erisim-kontrol-listesi.html', 'araclar/egitim-ai-surec-kontrol-listesi.html', 'rehberler/egitim-ai-otomasyon-rehberi.html', 'kanit/egitim-ai-3-sentetik-vaka.html', 'kanit/is-akisi-karsilastirma-kutuphanesi.html', 'karsilastirma-testi.html', 'kanit/gelir-karar-tablosu.html']
black=['day 17','gün 17','red bull','owner waiver','kullanıcı yalnız','run workflow','workflow çalıştır','chatgpt yapar','qa pass','internal plan']
for rel in new:
    p=root/rel
    if not p.exists(): raise SystemExit('DAY17 QA FAIL missing '+rel)
    t=p.read_text(encoding='utf-8',errors='strict'); low=t.lower()
    for b in black:
        if b in low: raise SystemExit('DAY17 QA FAIL internal wording '+b+' in '+rel)
    if '<link rel="canonical"' not in t or 'application/ld+json' not in t: raise SystemExit('DAY17 QA FAIL metadata '+rel)
    if 'synapse-measurement-v1.js' not in t: raise SystemExit('DAY17 QA FAIL measurement '+rel)
# Calculator: no form gate, visible assumptions, tool events
t=(root/'araclar/otomasyon-hata-maliyeti-hesaplayici.html').read_text(encoding='utf-8')
for tok in ['Varsayımlar','tool_start','tool_complete','Finansal sonuç garantisi değildir']:
    if tok not in t: raise SystemExit('DAY17 QA FAIL calculator token '+tok)
if '<form' in t.lower(): raise SystemExit('DAY17 QA FAIL calculator gated')
# Onboarding minimum field count and why text
o=(root/'pilot/pilot-onboarding.html').read_text(encoding='utf-8')
if o.count('required')<6 or o.count('class="why"')<6: raise SystemExit('DAY17 QA FAIL onboarding rationale')
if 'Özel setup ücretsiz değildir' not in o: raise SystemExit('DAY17 QA FAIL custom setup boundary')
# Comparison library exactly 20 cards
l=(root/'kanit/is-akisi-karsilastirma-kutuphanesi.html').read_text(encoding='utf-8')
if len(re.findall(r'class="comparecard"',l))!=20: raise SystemExit('DAY17 QA FAIL comparison card count')
if l.count('3 sentetik test')<20: raise SystemExit('DAY17 QA FAIL synthetic test labels')
# Single inbound form and privacy boundary
c=(root/'karsilastirma-testi.html').read_text(encoding='utf-8')
if c.lower().count('<form')!=1 or 'Ücretsiz custom build yok' not in c: raise SystemExit('DAY17 QA FAIL comparison form')
# VELA schema
j=json.loads((root/'public-proof/vela-v1/quote_schema_v1.json').read_text(encoding='utf-8'))
for k in ['customer','quote','payment','warnings','human_approval_required']:
    if k not in j: raise SystemExit('DAY17 QA FAIL VELA '+k)
if not j['human_approval_required']: raise SystemExit('DAY17 QA FAIL VELA human gate')
# Reality: 5 live tests must remain pending unless actual evidence exists
rows=list(csv.DictReader((root/'public-proof/comparison-v1/five_real_test_template.csv').open(encoding='utf-8')))
if len(rows)!=5 or any(r['status']!='PENDING' for r in rows): raise SystemExit('DAY17 QA FAIL real-test truth boundary')
# existing regression if present
for script in ['public-proof/reliability-regression-v2/run_regression.py','public-proof/site-catalog-readiness-v1/run_retrieval_tests.py','public-proof/site-catalog-readiness-v1/run_red_team.py']:
    p=root/script
    if p.exists(): subprocess.run(['python3',p.name],cwd=p.parent,check=True)
print('DAY17 QA PASS')
