from pathlib import Path
import sys,shutil,re
root=Path(sys.argv[1]); here=Path(__file__).resolve().parent
for p in (here/'files').rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(here/'files'); dst=root/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dst)
# kaynaklar discoverability, additive only
k=root/'kaynaklar.html'
if k.exists():
    t=k.read_text(encoding='utf-8'); marker='data-synapse-onboarding-risk="v1"'
    if marker not in t:
        block='''<section class="section" data-synapse-onboarding-risk="v1"><div class="container"><h2>Risk, onboarding ve karşılaştırma kanıtları</h2><div class="grid g2"><div class="card"><h3>Hata maliyeti</h3><p>Doğrudan kayıp + insan düzeltme süresini görün; varsayımları açık tutun.</p><a href="araclar/otomasyon-hata-maliyeti-hesaplayici.html">Hesaplayıcıyı aç →</a></div><div class="card"><h3>20 iş akışı karşılaştırma kartı</h3><p>Her kartta ölçüm, 3 sentetik test ve insan onayı sınırı.</p><a href="kanit/is-akisi-karsilastirma-kutuphanesi.html">Kütüphaneyi aç →</a></div></div></div></section>'''
        if '</main>' not in t: raise SystemExit('DAY17 APPLY FAIL kaynaklar main anchor')
        t=t.replace('</main>',block+'</main>',1); k.write_text(t,encoding='utf-8')
# sitemap
s=root/'sitemap.xml'
if s.exists():
    st=s.read_text(encoding='utf-8')
    urls=['araclar/otomasyon-hata-maliyeti-hesaplayici.html', 'pilot/pilot-onboarding.html', 'kanit/pilot-erisim-kontrol-listesi.html', 'araclar/egitim-ai-surec-kontrol-listesi.html', 'rehberler/egitim-ai-otomasyon-rehberi.html', 'kanit/egitim-ai-3-sentetik-vaka.html', 'kanit/is-akisi-karsilastirma-kutuphanesi.html', 'karsilastirma-testi.html', 'kanit/gelir-karar-tablosu.html']
    for rel in urls:
        u='https://synapseautomate.github.io/'+rel
        if u not in st:
            node=f'<url><loc>{u}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>\n'
            if '</urlset>' not in st: raise SystemExit('DAY17 APPLY FAIL sitemap close')
            st=st.replace('</urlset>',node+'</urlset>',1)
    s.write_text(st,encoding='utf-8')
print('DAY17 APPLY PASS')
