from pathlib import Path
import sys, shutil, re
root=Path(sys.argv[1]); here=Path(__file__).resolve().parent
src=here/'files/assets/js/synapse-measurement-v1.js'
dst=root/'assets/js/synapse-measurement-v1.js'
dst.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(src,dst)
# Privacy disclosure: additive, only if the page exists and disclosure is not already present.
p=root/'gizlilik.html'
if p.exists():
    t=p.read_text(encoding='utf-8')
    marker='data-synapse-analytics-disclosure="v1"'
    if marker not in t:
        block=('''<h2 data-synapse-analytics-disclosure="v1">Analitik ölçüm</h2>'''
               '''<p>Site kullanımını ve dönüşüm zincirini ölçmek için Google Analytics 4 kullanılır. Ölçüm katmanına form alanlarındaki ad, e-posta, telefon veya mesaj içeriği gönderilmez; sayfa görüntüleme, araç başlatma/tamamlama ve form gönderimi gibi olaylar ölçülür. Bu entegrasyonda reklam kişiselleştirme sinyalleri kullanılmaz.</p>''')
        anchor='<h2>İletişim</h2>'
        if anchor in t:
            t=t.replace(anchor,block+anchor,1)
        else:
            m=re.search(r'</article>',t,re.I)
            if not m: raise SystemExit('privacy page structure not recognized')
            t=t[:m.start()]+block+t[m.start():]
        p.write_text(t,encoding='utf-8')
print('GA4 APPLY PASS')
