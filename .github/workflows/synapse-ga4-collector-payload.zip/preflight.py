from pathlib import Path
import sys
root=Path(sys.argv[1])
js=root/'assets/js/synapse-measurement-v1.js'
if not js.exists(): raise SystemExit('measurement layer missing; run Day15 measurement release first')
t=js.read_text(encoding='utf-8',errors='strict')
required=['synapse_attribution_v1','lead_form_submit','asset_view','Attribution_First_Touch','Attribution_Last_Touch']
for x in required:
    if x not in t: raise SystemExit('measurement baseline missing token: '+x)
# Allow idempotent rerun only for the exact approved collector.
if 'G-' in t and 'G-HQSRRJ5HMZ' not in t:
    raise SystemExit('another GA4 Measurement ID is already present; refusing to overwrite')
print('GA4 PREFLIGHT PASS')
