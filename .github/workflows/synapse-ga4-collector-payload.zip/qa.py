from pathlib import Path
import sys,re,subprocess
root=Path(sys.argv[1]); js=root/'assets/js/synapse-measurement-v1.js'
t=js.read_text(encoding='utf-8')
checks={
 'measurement_id':'G-HQSRRJ5HMZ' in t,
 'gtag_loader':'googletagmanager.com/gtag/js?id=' in t,
 'ga_marker':'data-synapse-ga4' in t,
 'page_view':'send_page_view:true' in t,
 'no_google_signals':'allow_google_signals:false' in t,
 'no_ad_personalization':'allow_ad_personalization_signals:false' in t,
 'asset_view':"emit('asset_view')" in t,
 'form_event':"emit('lead_form_submit'" in t,
 'attribution':'Attribution_First_Touch' in t and 'Attribution_Last_Touch' in t,
}
for k,v in checks.items():
    print(k,'PASS' if v else 'FAIL')
    if not v: raise SystemExit('GA4 QA FAIL: '+k)
# Reject PII fields being explicitly sent through gtag payload code.
for bad in ['email:', 'phone:', 'name:', 'message:', 'telefon:', 'e_posta:']:
    if bad in t.lower(): raise SystemExit('possible PII event field: '+bad)
# Customer-facing internal wording audit for privacy addition.
p=root/'gizlilik.html'
if p.exists():
    g=p.read_text(encoding='utf-8')
    if 'data-synapse-analytics-disclosure="v1"' not in g: raise SystemExit('privacy disclosure missing')
    for bad in ['Day 15','Gün 15','run workflow','owner waiver','Red Bull','ChatGPT yapar','kullanıcı yalnız']:
        if bad.lower() in g.lower(): raise SystemExit('internal wording on privacy page: '+bad)
# JS syntax check when node is available.
node=shutil_which=None
try:
    import shutil
    node=shutil.which('node')
except Exception:
    node=None
if node:
    r=subprocess.run([node,'--check',str(js)],text=True,capture_output=True)
    print(r.stdout); print(r.stderr,file=sys.stderr)
    if r.returncode: raise SystemExit('JS syntax check failed')
print('GA4 COLLECTOR QA PASS')
