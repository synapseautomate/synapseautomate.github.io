from pathlib import Path
import sys,json,re
root=Path(sys.argv[1]); out=root/'public-proof/measurement-v1/schema_audit.json'
counts={k:0 for k in ['Organization','Service','Article','VideoObject','BreadcrumbList']}; parse_errors=[]; files_scanned=0
for p in root.rglob('*.html'):
    if '.git' in p.parts or '.github' in p.parts: continue
    files_scanned+=1; t=p.read_text(encoding='utf-8',errors='ignore')
    for raw in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',t,re.I|re.S):
        try:
            obj=json.loads(raw); stack=obj if isinstance(obj,list) else [obj]
            i=0
            while i < len(stack):
                x=stack[i]; i+=1
                if isinstance(x,dict) and isinstance(x.get('@graph'),list): stack.extend(x['@graph'])
                if not isinstance(x,dict): continue
                typ=x.get('@type',[]); typ=[typ] if isinstance(typ,str) else typ
                for k in counts:
                    if k in typ: counts[k]+=1
        except Exception as e: parse_errors.append({'file':str(p.relative_to(root)),'error':str(e)[:160]})
report={'version':'1.0.0','files_scanned':files_scanned,'type_counts':counts,'jsonld_parse_errors':parse_errors,'note':'Presence audit only; schema must still match visible page content.'}
out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
if parse_errors: raise SystemExit('JSON-LD parse errors found')
