from pathlib import Path
import sys,json,re
root=Path(sys.argv[1]); rows=[]; bad=[]
for p in root.rglob('*.html'):
    if '.git' in p.parts or '.github' in p.parts: continue
    t=p.read_text(encoding='utf-8',errors='ignore'); n=len(re.findall(r'<form\b',t,re.I))
    if n:
        ok='data-synapse-measurement="v1"' in t; rows.append({'file':str(p.relative_to(root)),'forms':n,'instrumented':ok})
        if not ok: bad.append(str(p.relative_to(root)))
out=root/'public-proof/measurement-v1/form_inventory.json';out.write_text(json.dumps({'version':'1.0.0','forms':rows},ensure_ascii=False,indent=2),encoding='utf-8')
print('forms',sum(x['forms'] for x in rows),'files',len(rows),'uninstrumented',len(bad))
if bad: raise SystemExit('Uninstrumented forms: '+', '.join(bad))
