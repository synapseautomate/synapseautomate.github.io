from pathlib import Path
import sys,re,json,subprocess
root=Path(sys.argv[1])
public=[root/'kanit/gelir-zinciri-olcum-sozlugu.html',root/'kanit/kanal-karsilastirma-karti.html',root/'kanit/ai-gorunurluk-olcum-sablonu.html',root/'araclar/hukuk-uyum-ai-surec-kontrol-listesi.html',root/'rehberler/hukuk-uyum-ai-otomasyon-rehberi.html',root/'kanit/hukuk-uyum-3-sentetik-vaka.html']
banned=['Day 15','Gün 15','Red Bull','owner waiver','run workflow','ChatGPT yapar','kullanıcı yalnız','internal execution','PASS:']
for p in public:
    t=p.read_text(encoding='utf-8')
    for b in banned:
        if b.lower() in t.lower(): raise SystemExit(f'customer surface contains internal wording: {p}: {b}')
    if 'overflow-x:hidden' not in t: raise SystemExit('mobile overflow guard missing: '+str(p))
    if '<meta name="description"' not in t or 'canonical' not in t: raise SystemExit('SEO metadata missing: '+str(p))
alltext='\n'.join(p.read_text(encoding='utf-8') for p in public)
for bad in ['AI’da 1. sıra garanti','%100 güvenli','gelir garantisi','hukuki tavsiyedir']:
    if bad.lower() in alltext.lower(): raise SystemExit('unsupported claim: '+bad)
ed=json.loads((root/'public-proof/measurement-v1/event_dictionary.json').read_text(encoding='utf-8'))
names=[x['name'] for x in ed['executive_events']]
if names!=['asset_view','tool_start','tool_complete','lead_form_submit','paid_conversion']: raise SystemExit('event dictionary drift')
for rel in ['araclar/site-ai-uyumluluk-taramasi.html','surec-analizi.html','talep-alindi.html']:
    t=(root/rel).read_text(encoding='utf-8')
    if 'data-synapse-measurement="v1"' not in t: raise SystemExit('measurement missing: '+rel)
if 'data-synapse-tool-hooks="v1"' not in (root/'araclar/site-ai-uyumluluk-taramasi.html').read_text(encoding='utf-8'): raise SystemExit('tool hooks missing')
def run(cwd,args):
    r=subprocess.run(args,cwd=cwd,text=True,capture_output=True); print(r.stdout); print(r.stderr,file=sys.stderr)
    if r.returncode: raise SystemExit('test failed: '+' '.join(args))
    return r.stdout
s=run(root/'public-proof/reliability-regression-v2',['python3','run_regression.py'])
if '"passed": 100' not in s or '"critical_failures": 0' not in s: raise SystemExit('100-case regression gate failed')
run(root/'public-proof/site-catalog-readiness-v1',['python3','run_retrieval_tests.py'])
run(root/'public-proof/site-catalog-readiness-v1',['python3','run_red_team.py'])
run(root/'public-proof/site-catalog-readiness-v1',['python3','deletion_test.py'])
run(root/'public-proof/pricing-v1',['python3','roi_calculator.py','--cases','40','--minutes','8','--loaded-hourly-cost','450','--monthly-error-impact','500','--correction-minutes','4','--model-ops-cost','30000','--pilot-price','24900'])
secret=re.compile(r'(ghp_[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{20,}|BEGIN (RSA|OPENSSH) PRIVATE KEY|sk-[A-Za-z0-9]{20,})')
for p in list((root/'public-proof/measurement-v1').rglob('*'))+public+[root/'assets/js/synapse-measurement-v1.js']:
    if p.is_file() and secret.search(p.read_text(encoding='utf-8',errors='ignore')): raise SystemExit('secret-like token: '+str(p))
print('DAY15 QA PASS')
