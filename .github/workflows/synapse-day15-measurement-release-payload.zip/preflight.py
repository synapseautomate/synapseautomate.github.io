from pathlib import Path
import sys
root=Path(sys.argv[1])
required=['surec-analizi.html','talep-alindi.html','sitemap.xml','llms.txt','araclar/site-ai-uyumluluk-taramasi.html','public-proof/reliability-regression-v2/run_regression.py','public-proof/site-catalog-readiness-v1/run_retrieval_tests.py','public-proof/site-catalog-readiness-v1/run_red_team.py']
missing=[x for x in required if not (root/x).exists()]
if missing: raise SystemExit('Missing required live paths: '+', '.join(missing))
checks={'surec-analizi.html':['formsubmit.co','Süreç Analizi','4.900 TL'],'araclar/site-ai-uyumluluk-taramasi.html':['id="show"','id="analysisCta"','site_catalog_readiness'],'talep-alindi.html':['Talep alındı']}
for rel,needles in checks.items():
    t=(root/rel).read_text(encoding='utf-8')
    for n in needles:
        if n not in t: raise SystemExit(f'Preflight anchor missing in {rel}: {n}')
print('DAY15 PREFLIGHT PASS')
