from pathlib import Path
import sys, json, hashlib, shutil, re
repo=Path(sys.argv[1]); payload=Path(__file__).resolve().parent
manifest=json.loads((payload/'manifest.json').read_text(encoding='utf-8'))['files']
for rel,expected in manifest.items():
    p=payload/'files'/rel
    if hashlib.sha256(p.read_bytes()).hexdigest()!=expected: raise SystemExit('payload hash mismatch: '+rel)
for rel in manifest:
    src=payload/'files'/rel; dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
marker='data-synapse-measurement="v1"'
script='<script data-synapse-measurement="v1" src="/assets/js/synapse-measurement-v1.js" defer></script>'
skip_parts={'.git','.github','node_modules','_release'}
for p in repo.rglob('*.html'):
    if any(part in skip_parts or re.fullmatch(r'D\d+',part or '') for part in p.parts): continue
    try:t=p.read_text(encoding='utf-8')
    except Exception: continue
    if marker in t: continue
    if re.search(r'</body\s*>',t,re.I): t=re.sub(r'</body\s*>',script+'</body>',t,count=1,flags=re.I)
    else: t+=script
    p.write_text(t,encoding='utf-8')
tool=repo/'araclar/site-ai-uyumluluk-taramasi.html'; t=tool.read_text(encoding='utf-8')
if 'data-synapse-tool-hooks="v1"' not in t:
    hook="""<script data-synapse-tool-hooks=\"v1\">(function(){var started=false,done=false;function emit(n,m){if(window.SynapseMeasurement)SynapseMeasurement.emit(n,m||{})}document.querySelectorAll('.choice').forEach(function(b){b.addEventListener('click',function(){if(!started){started=true;emit('tool_start',{tool_name:'site_catalog_readiness'})}})});var s=document.getElementById('show');if(s)s.addEventListener('click',function(){setTimeout(function(){var r=document.getElementById('result');if(r&&!r.hidden&&!done){done=true;emit('tool_complete',{tool_name:'site_catalog_readiness'})}},0)});var c=document.getElementById('analysisCta');if(c)c.addEventListener('click',function(){emit('cta_click',{cta_name:'paid_analysis',tool_name:'site_catalog_readiness'})});})();</script>"""
    t=re.sub(r'</body\s*>',hook+'</body>',t,count=1,flags=re.I)
    tool.write_text(t,encoding='utf-8')
p=repo/'surec-analizi.html'; t=p.read_text(encoding='utf-8')
if 'name="Attribution_Source"' not in t:
    anchor=re.search(r'(<form\b[^>]*action=["\']https://formsubmit\.co/[^>]+>)',t,re.I)
    if not anchor: raise SystemExit('paid form not found')
    fallback='<input name="Attribution_Source" type="hidden" value="direct"><input name="Attribution_Asset" type="hidden" value="/surec-analizi.html"><input name="Attribution_Cluster" type="hidden" value="">'
    t=t[:anchor.end()]+fallback+t[anchor.end():]
    p.write_text(t,encoding='utf-8')
urls=['kanit/gelir-zinciri-olcum-sozlugu.html','kanit/kanal-karsilastirma-karti.html','kanit/ai-gorunurluk-olcum-sablonu.html','araclar/hukuk-uyum-ai-surec-kontrol-listesi.html','rehberler/hukuk-uyum-ai-otomasyon-rehberi.html','kanit/hukuk-uyum-3-sentetik-vaka.html']
p=repo/'sitemap.xml'; t=p.read_text(encoding='utf-8'); adds=[]
for u in urls:
    loc='https://synapseautomate.github.io/'+u
    if loc not in t:adds.append('<url><loc>'+loc+'</loc></url>')
if adds:
    if not re.search(r'</urlset\s*>',t,re.I): raise SystemExit('sitemap close missing')
    t=re.sub(r'</urlset\s*>','\n'.join(adds)+'\n</urlset>',t,count=1,flags=re.I);p.write_text(t,encoding='utf-8')
p=repo/'llms.txt'; t=p.read_text(encoding='utf-8')
if '## Ölçüm ve Attribution' not in t:
    t=t.rstrip()+"""\n\n## Ölçüm ve Attribution\n- Gelir zinciri ölçüm sözlüğü: https://synapseautomate.github.io/kanit/gelir-zinciri-olcum-sozlugu.html\n- Kanal karşılaştırma kartı: https://synapseautomate.github.io/kanit/kanal-karsilastirma-karti.html\n- AI görünürlük ölçüm şablonu: https://synapseautomate.github.io/kanit/ai-gorunurluk-olcum-sablonu.html\n- Hukuk & Uyum rehberi: https://synapseautomate.github.io/rehberler/hukuk-uyum-ai-otomasyon-rehberi.html\n- Sınır: AI görünürlüğü, sıralama, üretim doğruluğu veya gelir garantisi verilmez.\n"""
    p.write_text(t+'\n',encoding='utf-8')
print('DAY15 APPLY PASS')
