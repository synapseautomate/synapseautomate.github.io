#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.')
base=json.loads((Path(__file__).parent/'baseline.json').read_text())
errs=[]
for rel,want in base['hashes'].items():
 p=repo/rel
 if not p.exists(): errs.append('missing '+rel); continue
 got=hashlib.sha256(p.read_bytes()).hexdigest()
 if got!=want: errs.append(f'changed baseline {rel}: {got} != {want}')
for rel in base['must_not_exist']:
 if (repo/rel).exists(): errs.append('new path already exists: '+rel)
if errs:
 print('PRE-FLIGHT FAIL'); [print('-',e) for e in errs]; sys.exit(21)
print('PASS: exact post-Day-12 flagship baseline')
