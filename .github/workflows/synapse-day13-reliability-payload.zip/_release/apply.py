#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,shutil,sys
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.')
root=Path(__file__).resolve().parents[1]
man=json.loads((Path(__file__).parent/'manifest.json').read_text())['files']
for rel,want in man.items():
 src=root/rel
 got=hashlib.sha256(src.read_bytes()).hexdigest()
 if got!=want: raise SystemExit('payload hash mismatch '+rel)
 dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
print(f'PASS: applied {len(man)} Day-13 files')
