#!/usr/bin/env python3
from pathlib import Path
from html.parser import HTMLParser
import csv,json,hashlib,re,subprocess,sys
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.')
root=Path(__file__).resolve().parents[1]
man=json.loads((Path(__file__).parent/'manifest.json').read_text())['files']
errors=[]
def run(cmd):
 p=subprocess.run(cmd,cwd=repo,text=True,capture_output=True)
 if p.returncode: errors.append('CMD FAIL '+ ' '.join(cmd)+'\n'+(p.stdout+p.stderr)[-1500:])
 return p
# exact applied hashes
for rel,want in man.items():
 p=repo/rel
 if not p.exists(): errors.append('missing '+rel); continue
 got=hashlib.sha256(p.read_bytes()).hexdigest()
 if got!=want: errors.append('hash mismatch '+rel)
# current + regression gates
p=run(['python3','public-proof/reliability-regression-v2/run_regression.py','public-proof/reliability-regression-v2/cases.csv'])
if p.returncode==0:
 try:
  d=json.loads(p.stdout)
  if not(d.get('cases')==100 and d.get('passed')==100 and d.get('critical_failures')==0): errors.append('v2 result mismatch')
 except Exception as e: errors.append('v2 result parse '+str(e))
run(['python3','public-proof/reliability-regression-v1/run_regression.py','public-proof/reliability-regression-v1/test_cases.csv'])
run(['python3','public-proof/reliability-regression-v1/run_mutation_checks.py','public-proof/reliability-regression-v1/mutation_checks.csv'])
run(['python3','public-proof/structured-extraction-v1/validate.py'])
run(['python3','public-proof/structured-extraction-v1/test_ingest.py'])
run(['python3','public-proof/human-approval/validate_rules.py'])
# suite integrity
score=json.loads((repo/'public-proof/reliability-regression-v2/scoreboard.json').read_text())
if score['after_root_controls']!={'passed':100,'failed':0,'critical_mismatches':0,'major_mismatches':0,'minor_mismatches':0}: errors.append('scoreboard mismatch')
held=json.loads((repo/'public-proof/reliability-regression-v2/heldout_20_results.json').read_text())
if not(held['cases']==20 and held['passed']==20 and held['critical_errors']==0): errors.append('heldout mismatch')
# HTML basic links/title/UTF8
class P(HTMLParser):
 def __init__(self): super().__init__(); self.links=[]; self.title=False
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='title': self.title=True
  if tag in ('a','img'):
   v=a.get('href') or a.get('src')
   if v:self.links.append(v)
pages=['kanit/100-vaka-ai-guvenilirlik-regresyon-raporu.html','rehberler/e-ticaret-ai-otomasyon-guvenlik-rehberi.html','araclar/e-ticaret-ai-risk-kontrol-listesi.html','kanit/e-ticaret-ai-3-sentetik-vaka.html','kanit/vaka-2-regression-root-fix.html','standards/enterprise-ai-workflow-reliability-standard-2026.html','kaynaklar.html']
for rel in pages:
 pth=repo/rel; txt=pth.read_text(encoding='utf-8'); parser=P(); parser.feed(txt)
 if not parser.title: errors.append('missing title '+rel)
 if 'charset="utf-8"' not in txt.lower(): errors.append('missing utf8 '+rel)
 if '{{' in txt or 'TODO' in txt or 'lorem ipsum' in txt.lower(): errors.append('template residue '+rel)
 for v in parser.links:
  if v.startswith(('#','http:','https:','mailto:','tel:','javascript:','data:')): continue
  target=(pth.parent/v.split('?')[0].split('#')[0]).resolve()
  if not target.exists(): errors.append(f'broken relative link {rel} -> {v}')
# claim/language gates
report=(repo/'kanit/100-vaka-ai-guvenilirlik-regresyon-raporu.html').read_text(encoding='utf-8')
for phrase in ['100/100','STOP_ESCALATE','Production accuracy','Claim sınırı','10 kritik soru']:
 if phrase not in report: errors.append('report missing '+phrase)
if report.count('"@type": "Question"')<10: errors.append('FAQ schema <10')
for rel in ['D13/linkedin_company_native_video_post.md','D13/linkedin_company_data_post.md','public-proof/reliability-regression-v2/README.md']:
 t=(repo/rel).read_text(encoding='utf-8').lower()
 if '100/100' not in t or not(('production' in t or 'üretim' in t) and ('değil' in t or 'not' in t or 'guarantee' in t)): errors.append('limitation missing '+rel)
# sitemap/llms
sm=(repo/'sitemap.xml').read_text()
for u in ['100-vaka-ai-guvenilirlik-regresyon-raporu.html','e-ticaret-ai-otomasyon-guvenlik-rehberi.html','e-ticaret-ai-risk-kontrol-listesi.html','e-ticaret-ai-3-sentetik-vaka.html','vaka-2-regression-root-fix.html']:
 if u not in sm: errors.append('sitemap missing '+u)
if 'Reliability Regression v2' not in (repo/'llms.txt').read_text(): errors.append('llms missing v2')
# secrets / raw personal data in payload text files
secret=re.compile(r'(AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{20,}|BEGIN [A-Z ]*PRIVATE KEY)')
for rel in man:
 p=repo/rel
 if p.suffix.lower() in {'.html','.md','.txt','.csv','.json','.py'}:
  t=p.read_text(encoding='utf-8')
  if secret.search(t): errors.append('secret-like token '+rel)
  if '@gmail.com' in t or '@hotmail.com' in t or 'TC Kimlik' in t: errors.append('raw personal data '+rel)
if errors:
 print('DAY13 QA FAIL'); [print('-',e) for e in errors]; sys.exit(1)
print('PASS: Day13 Red Bull quality gate')
print('v2=100/100; critical=0; heldout=20/20; claim boundary=PASS; links=UTF8=secrets=PASS')
