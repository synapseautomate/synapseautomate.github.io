from pathlib import Path
import re, sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')

def patch_once(path, old, new, label):
    p=root/path
    t=p.read_text(encoding='utf-8')
    if new in t:
        print(label,'already applied'); return
    if old not in t:
        raise SystemExit(f'{label}: anchor missing in {path}')
    p.write_text(t.replace(old,new,1),encoding='utf-8')
    print(label,'patched')

# kaynaklar: upgrade existing tool card, no duplicate tool.
patch_once('kaynaklar.html',
'<article class="card"><h3>Site &amp; Katalog AI Uyumluluğu</h3><p>7 kategoride doğrulanabilirlik boşluklarını görün.</p><a class="more" href="araclar/site-ai-uyumluluk-taramasi.html">Örnek taramayı aç →</a></article>',
'<article class="card"><h3>Site &amp; Katalog AI Hazırlık Taraması</h3><p>7 kategoride kaynak, güncellik, katalog yapısı, retrieval, yetki, insan onayı ve regression boşluklarını görün. Sonuç için form gerekmez.</p><a class="more" href="araclar/site-ai-uyumluluk-taramasi.html">Ücretsiz taramayı başlat →</a></article>',
'kaynaklar tool card')

# index: premium free-value-first funnel block using existing design classes.
p=root/'index.html'; t=p.read_text(encoding='utf-8')
block='''<section class="section-tight" id="site-katalog-hazirlik"><div class="container"><div class="featured"><div><div class="kicker">Ücretsiz Site &amp; Katalog AI Hazırlık Taraması</div><h2>Önce eksik kontrolü görün. Sonra ücretli analize karar verin.</h2><p class="lead">Yedi kategoride sonucu form vermeden görün. Hazırlık taraması 0 TL; Süreç Analizi 4.900 TL / $149; kontrollü pilot gerekirse 24.900 TL / $750 başlangıç fiyatıyla ayrı kapsamlanır.</p></div><div><a class="btn btn-primary" href="araclar/site-ai-uyumluluk-taramasi.html?utm_source=homepage&utm_medium=organic&utm_campaign=site_catalog_readiness&utm_content=readiness_scan">Ücretsiz Taramayı Başlat</a></div></div></div></section>'''
if 'id="site-katalog-hazirlik"' not in t:
    if '</main>' not in t: raise SystemExit('index: </main> missing')
    p.write_text(t.replace('</main>',block+'</main>',1),encoding='utf-8')
    print('index funnel block patched')
else: print('index funnel block already applied')

# products: make the existing web/catalog card expose the free scan and price ladder.
p=root/'urunler.html'; t=p.read_text(encoding='utf-8')
old='<article class="card"><span class="micro">Web hazırlığı</span><h3>Web ve Katalog Hazırlık Sistemi</h3><p>Site ve katalog içeriğini yapay zekâ asistanları için bulunabilir, doğrulanabilir ve kontrollü işlem yapılabilir hale getirir.</p><a class="more" href="urunler/agentready.html">Çözümü incele</a></article>'
new='<article class="card"><span class="micro">Web hazırlığı</span><h3>Web ve Katalog Hazırlık Sistemi</h3><p>Site ve katalog içeriğini bulunabilir, doğrulanabilir ve kontrollü işlem yapılabilir hale getirmek için hazırlık boşluklarını görünür kılar.</p><p><strong>Ücretsiz tarama:</strong> 0 TL · <strong>Süreç Analizi:</strong> 4.900 TL / $149 · <strong>Kontrollü Pilot:</strong> 24.900 TL / $750 başlangıç.</p><a class="more" href="araclar/site-ai-uyumluluk-taramasi.html">Ücretsiz hazırlık taraması →</a><br><a class="more" href="urunler/agentready.html">Çözümü incele →</a></article>'
if new not in t:
    if old not in t: raise SystemExit('urunler card anchor missing')
    p.write_text(t.replace(old,new,1),encoding='utf-8'); print('urunler card patched')
else: print('urunler card already applied')

# paid analysis: capture tool attribution; add 48h scope clarification without inventing new fixed price.
p=root/'surec-analizi.html'; t=p.read_text(encoding='utf-8')
if 'name="Arac"' not in t:
    anchor='<input id="lead-landing" name="Giris_Sayfasi" type="hidden" value="/surec-analizi.html"/>'
    repl=anchor+'<input id="lead-tool" name="Arac" type="hidden" value=""/><input id="lead-result" name="Tarama_Ozeti" type="hidden" value=""/>'
    if anchor not in t: raise SystemExit('surec hidden input anchor missing')
    t=t.replace(anchor,repl,1)
if '48 saatlik dar kapsamlı düzeltme' not in t:
    anchor='<p class="small">Aylık hizmet otomatik devam etmez. Pilotun gerçek değer üretmesi ve sürekli izleme/iyileştirme ihtiyacının bulunması gerekir.</p>'
    repl=anchor+'<p class="small"><strong>48 saatlik dar kapsamlı düzeltme:</strong> yalnız ücretli analizde tek ve güvenli bir düzeltme alanı doğrulanırsa Kontrollü Pilot kapsamında yazılı başlangıç/bitiş koşullarıyla tanımlanır. Kapsam büyürse takvim ayrıca belirtilir.</p>'
    if anchor not in t: raise SystemExit('surec price note anchor missing')
    t=t.replace(anchor,repl,1)
# extend attribution script safely
old="var a=document.getElementById('lead-source'),b=document.getElementById('lead-campaign'),c=document.getElementById('lead-landing');if(a)a.value=src.slice(0,80);if(b)b.value=cmp.slice(0,120);if(c)c.value=location.pathname.slice(0,160);"
new="var a=document.getElementById('lead-source'),b=document.getElementById('lead-campaign'),c=document.getElementById('lead-landing'),d=document.getElementById('lead-tool'),e=document.getElementById('lead-result');if(a)a.value=src.slice(0,80);if(b)b.value=cmp.slice(0,120);if(c)c.value=location.pathname.slice(0,160);if(d)d.value=(p.get('tool')||'').slice(0,80);if(e)e.value=(p.get('result')||'').slice(0,120);"
if new not in t:
    if old not in t: raise SystemExit('surec attribution anchor missing')
    t=t.replace(old,new,1)
p.write_text(t,encoding='utf-8'); print('surec attribution patched')

# sitemap: add canonical new customer-facing URLs.
p=root/'sitemap.xml'; t=p.read_text(encoding='utf-8')
urls=[
'araclar/site-ai-uyumluluk-taramasi.html','kanit/site-katalog-ai-hazirlik-metodolojisi.html','kanit/site-katalog-ai-hazirlik-ornek-rapor.html','rehberler/site-katalog-ai-hazirlik-rehberi.html','araclar/emlak-ai-surec-kontrol-listesi.html','rehberler/emlak-ai-otomasyon-hazirlik-rehberi.html','kanit/emlak-ai-3-sentetik-vaka.html',
'rehberler/ai-otomasyon-hazirlik-kontrolu.html','rehberler/ai-surec-denetimi.html','rehberler/workflow-hazirlik-hesaplayici.html','rehberler/site-ai-hazirlik.html','rehberler/katalog-ai-hazirlik.html','rehberler/prompt-injection-is-akisi-kontrolu.html','rehberler/ai-data-provenance.html','rehberler/eski-fiyat-stok-ai-riski.html','rehberler/ai-tool-yetki-sinirlari.html','rehberler/ai-insan-onayi-is-akisi.html']
for u in urls:
    loc=f'https://synapseautomate.github.io/{u}'
    if loc not in t:
        t=t.replace('</urlset>',f'<url><loc>{loc}</loc></url>\n</urlset>')
p.write_text(t,encoding='utf-8'); print('sitemap patched')

# llms.txt: canonical discovery block, customer-facing wording only.
p=root/'llms.txt'; t=p.read_text(encoding='utf-8')
block='''\n## Site & Katalog AI Hazırlık\n- Ücretsiz tarama: https://synapseautomate.github.io/araclar/site-ai-uyumluluk-taramasi.html\n- Metodoloji: https://synapseautomate.github.io/kanit/site-katalog-ai-hazirlik-metodolojisi.html\n- Sentetik örnek rapor: https://synapseautomate.github.io/kanit/site-katalog-ai-hazirlik-ornek-rapor.html\n- Emlak hazırlık rehberi: https://synapseautomate.github.io/rehberler/emlak-ai-otomasyon-hazirlik-rehberi.html\n- Sınır: hazırlık taraması bir AI görünürlük/sıralama, üretim doğruluğu veya güvenlik garantisi değildir.\n'''
if '## Site & Katalog AI Hazırlık' not in t:
    p.write_text(t.rstrip()+block+'\n',encoding='utf-8'); print('llms patched')
else: print('llms already applied')
