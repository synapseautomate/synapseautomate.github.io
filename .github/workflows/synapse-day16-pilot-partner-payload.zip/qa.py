from pathlib import Path
import sys,json,csv,subprocess
root=Path(sys.argv[1])
new=[
'pilot/kontrollu-ai-is-akisi-pilotu.html','kanit/partner-ready-pilot-ornek-raporu.html','araclar/uretim-lojistik-ai-surec-kontrol-listesi.html','rehberler/uretim-lojistik-ai-otomasyon-rehberi.html','kanit/uretim-lojistik-3-sentetik-vaka.html']
black=['day 16','gün 16','red bull','owner waiver','kullanıcı yalnız','run workflow','workflow çalıştır','chatgpt yapar','qa pass','internal plan']
for rel in new:
    p=root/rel
    if not p.exists(): raise SystemExit('DAY16 QA FAIL missing '+rel)
    t=p.read_text(encoding='utf-8',errors='strict'); low=t.lower()
    for b in black:
        if b in low: raise SystemExit('DAY16 QA FAIL internal wording '+b+' in '+rel)
    if '<link rel="canonical"' not in t or 'application/ld+json' not in t: raise SystemExit('DAY16 QA FAIL metadata '+rel)
    if 'synapse-measurement-v1.js' not in t: raise SystemExit('DAY16 QA FAIL measurement '+rel)
pilot=(root/'pilot/kontrollu-ai-is-akisi-pilotu.html').read_text(encoding='utf-8')
for token in ['24.900 TL / $750','4.900 TL / $149','7 gün shadow','7 gün kontrollü']:
    if token not in pilot: raise SystemExit('DAY16 QA FAIL pilot token '+token)
x=(root/'araclar/uretim-lojistik-ai-surec-kontrol-listesi.html').read_text(encoding='utf-8')
if '<form' in x.lower(): raise SystemExit('DAY16 QA FAIL tool has form gate')
for token in ['14 kontrol','id="result"',"SynapseMeasurement.emit('tool_start'", "SynapseMeasurement.emit('tool_complete'"]:
    if token not in x: raise SystemExit('DAY16 QA FAIL tool token '+token)
for rel in ['public-proof/pilot-v1/pilot_sow_v1.md','public-proof/pilot-v1/data_appendix_v1.md','public-proof/pilot-v1/monthly_service_economics.csv','public-proof/pilot-v1/batch_sop_v1.md','public-proof/partner-kit-v1/partner_offer_template_v1.json']:
    if not (root/rel).exists(): raise SystemExit('DAY16 QA FAIL proof '+rel)
rows=list(csv.DictReader((root/'public-proof/pilot-v1/monthly_service_economics.csv').open(encoding='utf-8')))
if len(rows)!=3 or not any(float(r['gross_margin_pct'])<10 for r in rows): raise SystemExit('DAY16 QA FAIL economics scenarios')
j=json.loads((root/'public-proof/partner-kit-v1/partner_offer_template_v1.json').read_text(encoding='utf-8'))
if j['offer']['price_try']!=24900 or j['scope']['workflows']!=1 or j['scope']['external_autonomous_action'] is not False: raise SystemExit('DAY16 QA FAIL partner template')
sm=(root/'sitemap.xml').read_text(encoding='utf-8')
for u in ['pilot/kontrollu-ai-is-akisi-pilotu.html','kanit/partner-ready-pilot-ornek-raporu.html','araclar/uretim-lojistik-ai-surec-kontrol-listesi.html','rehberler/uretim-lojistik-ai-otomasyon-rehberi.html','kanit/uretim-lojistik-3-sentetik-vaka.html']:
    if u not in sm: raise SystemExit('DAY16 QA FAIL sitemap '+u)
# optional regression suites, run from their own directories so relative case files resolve
for script in ['public-proof/reliability-regression-v2/run_regression.py','public-proof/site-catalog-readiness-v1/run_retrieval_tests.py','public-proof/site-catalog-readiness-v1/run_red_team.py']:
    p=root/script
    if p.exists(): subprocess.run(['python3',p.name],cwd=p.parent,check=True)
print('DAY16 QA PASS')
