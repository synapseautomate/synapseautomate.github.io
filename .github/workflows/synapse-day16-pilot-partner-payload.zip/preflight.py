from pathlib import Path
import sys
root=Path(sys.argv[1])
checks={
 'assets/js/synapse-measurement-v1.js':['G-HQSRRJ5HMZ','asset_view','lead_form_submit','SynapseMeasurement'],
 'kanit/gelir-zinciri-olcum-sozlugu.html':['Gelir Zinciri','synapse-measurement-v1.js'],
 'kaynaklar.html':['Synapse'],
 'sitemap.xml':['<urlset']
}
for rel,tokens in checks.items():
    p=root/rel
    if not p.exists(): raise SystemExit('DAY16 PREFLIGHT FAIL missing '+rel)
    t=p.read_text(encoding='utf-8',errors='strict')
    for token in tokens:
        if token not in t: raise SystemExit('DAY16 PREFLIGHT FAIL token '+token+' in '+rel)
print('DAY16 PREFLIGHT PASS')
