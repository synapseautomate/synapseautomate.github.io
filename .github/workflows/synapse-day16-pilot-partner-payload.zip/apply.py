from pathlib import Path
import sys, shutil
root=Path(sys.argv[1]); here=Path(__file__).resolve().parent
for p in (here/'files').rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(here/'files'); dst=root/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dst)
# kaynaklar discoverability block
k=root/'kaynaklar.html'; t=k.read_text(encoding='utf-8')
marker='data-synapse-pilot-kit="v1"'
if marker not in t:
    block=(
    '<section class="section" data-synapse-pilot-kit="v1"><div class="container">'
    '<h2>Kontrollü pilot ve partner-ready teslimat</h2><div class="grid g2">'
    '<div class="card"><h3>Kontrollü AI İş Akışı Pilotu</h3><p>Tek iş akışı, baseline, human gate ve ölçülebilir başarı metriği.</p>'
    '<a href="pilot/kontrollu-ai-is-akisi-pilotu.html">Pilot kapsamını incele -&gt;</a></div>'
    '<div class="card"><h3>Partner-ready örnek rapor</h3><p>Kaynak, hata, insan aksiyonu ve limitation alanlarını taşıyan sentetik örnek.</p>'
    '<a href="kanit/partner-ready-pilot-ornek-raporu.html">Örnek raporu aç -&gt;</a></div>'
    '</div></div></section>')
    if '</main>' not in t: raise SystemExit('DAY16 APPLY FAIL kaynaklar main anchor missing')
    t=t.replace('</main>',block+'</main>',1); k.write_text(t,encoding='utf-8')
# sitemap additive
s=root/'sitemap.xml'; st=s.read_text(encoding='utf-8')
urls=[
'https://synapseautomate.github.io/pilot/kontrollu-ai-is-akisi-pilotu.html',
'https://synapseautomate.github.io/kanit/partner-ready-pilot-ornek-raporu.html',
'https://synapseautomate.github.io/araclar/uretim-lojistik-ai-surec-kontrol-listesi.html',
'https://synapseautomate.github.io/rehberler/uretim-lojistik-ai-otomasyon-rehberi.html',
'https://synapseautomate.github.io/kanit/uretim-lojistik-3-sentetik-vaka.html']
for u in urls:
    if u not in st:
        node=f'<url><loc>{u}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>\n'
        if '</urlset>' not in st: raise SystemExit('DAY16 APPLY FAIL sitemap close missing')
        st=st.replace('</urlset>',node+'</urlset>',1)
s.write_text(st,encoding='utf-8')
# llms append
append=(here/'llms_append.txt').read_text(encoding='utf-8')
for rel in ['llms.txt','llms-demand.txt']:
    p=root/rel
    if p.exists():
        x=p.read_text(encoding='utf-8')
        if 'kontrollu-ai-is-akisi-pilotu.html' not in x:
            p.write_text(x.rstrip()+'\n'+append,encoding='utf-8')
print('DAY16 APPLY PASS')
