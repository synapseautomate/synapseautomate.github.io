from pathlib import Path
from html.parser import HTMLParser
import subprocess, sys, re, json
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
changed=[
'index.html','urunler.html','kaynaklar.html','surec-analizi.html',
'araclar/site-ai-uyumluluk-taramasi.html','kanit/site-katalog-ai-hazirlik-metodolojisi.html','kanit/site-katalog-ai-hazirlik-ornek-rapor.html',
'araclar/emlak-ai-surec-kontrol-listesi.html','rehberler/emlak-ai-otomasyon-hazirlik-rehberi.html','kanit/emlak-ai-3-sentetik-vaka.html',
'rehberler/ai-otomasyon-hazirlik-kontrolu.html','rehberler/ai-surec-denetimi.html','rehberler/workflow-hazirlik-hesaplayici.html','rehberler/site-ai-hazirlik.html','rehberler/katalog-ai-hazirlik.html','rehberler/prompt-injection-is-akisi-kontrolu.html','rehberler/ai-data-provenance.html','rehberler/eski-fiyat-stok-ai-riski.html','rehberler/ai-tool-yetki-sinirlari.html','rehberler/ai-insan-onayi-is-akisi.html']
banned=['day 14','gün 14','day14','red bull','owner waiver','run workflow','kullanıcı yalnız','chatgpt','source of truth','smoke pass','qa gate','bana hitaben']
errs=[]
for rel in changed:
 p=root/rel
 if not p.exists(): errs.append(f'missing {rel}'); continue
 t=p.read_text(encoding='utf-8',errors='strict')
 low=t.lower()
 for b in banned:
  if b in low: errs.append(f'internal wording {b} in {rel}')
 if not re.search(r'<meta[^>]+(?:name=\"viewport\"|name=viewport)[^>]*>',t,re.I): errs.append(f'viewport missing {rel}')
 if '<title>' not in t: errs.append(f'title missing {rel}')
 if rel.startswith(('araclar/','rehberler/','kanit/')) and 'canonical' not in t: errs.append(f'canonical missing {rel}')
# Free value before form gate.
t=(root/'araclar/site-ai-uyumluluk-taramasi.html').read_text(encoding='utf-8')
if re.search(r'<form\b',t,re.I): errs.append('free readiness scan contains a form gate')
for needle in ['yedi kategori','4.900 TL','$149','24.900 TL','$750','form']:
 if needle.lower() not in t.lower(): errs.append(f'free scan missing {needle}')
# Price consistency on public surfaces.
for rel in ['index.html','urunler.html','surec-analizi.html','araclar/site-ai-uyumluluk-taramasi.html']:
 t=(root/rel).read_text(encoding='utf-8')
 for x in ['4.900 TL','$149','24.900 TL','$750']:
  if x not in t: errs.append(f'price mismatch/missing {x} in {rel}')
# FAQ has full ladder.
mt=(root/'kanit/site-katalog-ai-hazirlik-metodolojisi.html').read_text(encoding='utf-8')
for x in ['4.900 TL','$149','24.900 TL','$750','14.900 TL','$449']:
 if x not in mt: errs.append(f'FAQ pricing missing {x}')
# Claim boundary.
for rel in changed:
 t=(root/rel).read_text(encoding='utf-8').lower()
 if 'ai görünürlük garantisi' in t and 'değil' not in t: errs.append(f'absolute visibility claim {rel}')
# Proof tests.
proof=root/'public-proof/site-catalog-readiness-v1'
for script in ['run_retrieval_tests.py','run_red_team.py','deletion_test.py']:
 r=subprocess.run([sys.executable,str(proof/script)],cwd=root,text=True,capture_output=True)
 print(r.stdout.strip())
 if r.returncode: errs.append(f'{script} failed')
# Public proof must be synthetic/no raw secrets.
secret_re=re.compile(r'(AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA|EC|OPENSSH|PRIVATE) KEY-----)')
for p in proof.rglob('*'):
 if p.is_file():
  s=p.read_text(encoding='utf-8',errors='ignore')
  if secret_re.search(s): errs.append(f'secret-like token {p.relative_to(root)}')
# Attribution fields in paid request.
st=(root/'surec-analizi.html').read_text(encoding='utf-8')
for x in ['name="Arac"','name="Tarama_Ozeti"','48 saatlik dar kapsamlı düzeltme']:
 if x not in st: errs.append(f'analysis attribution/scope missing {x}')
# Sitemap + llms discovery.
sm=(root/'sitemap.xml').read_text(encoding='utf-8'); lm=(root/'llms.txt').read_text(encoding='utf-8')
for u in ['site-ai-uyumluluk-taramasi.html','site-katalog-ai-hazirlik-metodolojisi.html','emlak-ai-otomasyon-hazirlik-rehberi.html']:
 if u not in sm: errs.append(f'sitemap missing {u}')
if '## Site & Katalog AI Hazırlık' not in lm: errs.append('llms discovery block missing')
if errs:
 print('\nBRAND / FUNNEL QUALITY GATE FAIL')
 for e in errs: print('-',e)
 raise SystemExit(1)
print('\nBRAND / FUNNEL QUALITY GATE PASS')
print('free value before form: PASS')
print('pricing consistency: PASS')
print('retrieval tests: PASS')
print('adversarial 20 cases: PASS')
print('authorized deletion test: PASS')
print('internal/customer wording boundary: PASS')
