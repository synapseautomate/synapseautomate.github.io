from pathlib import Path
import sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
checks={
 'index.html':['Süreç Analizi İste'],
 'urunler.html':['Web ve Katalog Hazırlık Sistemi'],
 'kaynaklar.html':['araclar/site-ai-uyumluluk-taramasi.html'],
 'surec-analizi.html':['4.900 TL','$149'],
 'sitemap.xml':['</urlset>'],
 'llms.txt':['Synapse Automate']
}
errs=[]
for rel,anchors in checks.items():
 p=root/rel
 if not p.exists(): errs.append(f'missing {rel}'); continue
 t=p.read_text(encoding='utf-8',errors='strict')
 if not all(a in t for a in anchors): errs.append(f'anchor mismatch {rel}')
if errs:
 print('READINESS FUNNEL PREFLIGHT FAIL'); [print('-',e) for e in errs]; raise SystemExit(21)
print('READINESS FUNNEL PREFLIGHT PASS')
