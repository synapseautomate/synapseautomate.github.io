from pathlib import Path
import re, sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')

class PatchError(RuntimeError): pass

def read(rel):
    p=root/rel
    if not p.exists(): raise PatchError(f'missing target: {rel}')
    return p, p.read_text(encoding='utf-8')

def write(p,t,label):
    p.write_text(t,encoding='utf-8')
    print(label,'patched')

# 1) kaynaklar.html — replace whichever article owns the scan link.
p,t=read('kaynaklar.html')
new_card='<article class="card"><h3>Site &amp; Katalog AI Hazırlık Taraması</h3><p>7 kategoride kaynak, güncellik, katalog yapısı, retrieval, yetki, insan onayı ve regression boşluklarını görün. Sonuç için form gerekmez.</p><a class="more" href="araclar/site-ai-uyumluluk-taramasi.html">Ücretsiz taramayı başlat →</a></article>'
if new_card not in t:
    pat=re.compile(r'<article\b[^>]*>.*?<a\b[^>]*href=["\']araclar/site-ai-uyumluluk-taramasi\.html["\'][^>]*>.*?</a>.*?</article>',re.I|re.S)
    if not pat.search(t):
        raise PatchError('kaynaklar: scan card container not found')
    t=pat.sub(new_card,t,count=1)
    write(p,t,'kaynaklar tool card')
else: print('kaynaklar tool card already applied')

# 2) index.html — insert only once before closing main.
p,t=read('index.html')
block='''<section class="section-tight" id="site-katalog-hazirlik"><div class="container"><div class="featured"><div><div class="kicker">Ücretsiz Site &amp; Katalog AI Hazırlık Taraması</div><h2>Önce eksik kontrolü görün. Sonra ücretli analize karar verin.</h2><p class="lead">Yedi kategoride sonucu form vermeden görün. Hazırlık taraması 0 TL; Süreç Analizi 4.900 TL / $149; kontrollü pilot gerekirse 24.900 TL / $750 başlangıç fiyatıyla ayrı kapsamlanır.</p></div><div><a class="btn btn-primary" href="araclar/site-ai-uyumluluk-taramasi.html?utm_source=homepage&amp;utm_medium=organic&amp;utm_campaign=site_catalog_readiness&amp;utm_content=readiness_scan">Ücretsiz Taramayı Başlat</a></div></div></div></section>'''
if 'id="site-katalog-hazirlik"' not in t:
    if not re.search(r'</main\s*>',t,re.I): raise PatchError('index: </main> missing')
    t=re.sub(r'</main\s*>',block+'</main>',t,count=1,flags=re.I)
    write(p,t,'index funnel block')
else: print('index funnel block already applied')

# 3) urunler.html — replace the semantic article containing AgentReady link.
p,t=read('urunler.html')
new_card='<article class="card"><span class="micro">Web hazırlığı</span><h3>Web ve Katalog Hazırlık Sistemi</h3><p>Site ve katalog içeriğini bulunabilir, doğrulanabilir ve kontrollü işlem yapılabilir hale getirmek için hazırlık boşluklarını görünür kılar.</p><p><strong>Ücretsiz tarama:</strong> 0 TL · <strong>Süreç Analizi:</strong> 4.900 TL / $149 · <strong>Kontrollü Pilot:</strong> 24.900 TL / $750 başlangıç.</p><a class="more" href="araclar/site-ai-uyumluluk-taramasi.html">Ücretsiz hazırlık taraması →</a><br><a class="more" href="urunler/agentready.html">Çözümü incele →</a></article>'
if 'Ücretsiz hazırlık taraması' not in t or '24.900 TL' not in t:
    pat=re.compile(r'<article\b[^>]*>.*?<a\b[^>]*href=["\']urunler/agentready\.html["\'][^>]*>.*?</a>.*?</article>',re.I|re.S)
    matches=list(pat.finditer(t))
    if not matches: raise PatchError('urunler: AgentReady card container not found')
    # Prefer the article that explicitly names Web/Katalog if multiple.
    m=next((m for m in matches if re.search(r'Web\s+ve\s+Katalog',m.group(0),re.I)),matches[0])
    t=t[:m.start()]+new_card+t[m.end():]
    write(p,t,'urunler readiness card')
else: print('urunler readiness card already applied')

# 4) surec-analizi.html — robust additive attribution + 48h note.
p,t=read('surec-analizi.html')
if 'name="Arac"' not in t:
    pat=re.compile(r'(<input\b[^>]*\bid=["\']lead-landing["\'][^>]*>)',re.I)
    m=pat.search(t)
    if not m: raise PatchError('surec: lead-landing input missing')
    ins='<input id="lead-tool" name="Arac" type="hidden" value=""/><input id="lead-result" name="Tarama_Ozeti" type="hidden" value=""/>'
    t=t[:m.end()]+ins+t[m.end():]
    print('surec attribution inputs patched')
else: print('surec attribution inputs already applied')

if '48 saatlik dar kapsamlı düzeltme' not in t:
    para_pat=re.compile(r'(<p\b[^>]*class=["\'][^"\']*small[^"\']*["\'][^>]*>[^<]*Aylık hizmet otomatik devam etmez\..*?</p>)',re.I|re.S)
    m=para_pat.search(t)
    note='<p class="small"><strong>48 saatlik dar kapsamlı düzeltme:</strong> yalnız ücretli analizde tek ve güvenli bir düzeltme alanı doğrulanırsa Kontrollü Pilot kapsamında yazılı başlangıç/bitiş koşullarıyla tanımlanır. Kapsam büyürse takvim ayrıca belirtilir.</p>'
    if m:
        t=t[:m.end()]+note+t[m.end():]
    else:
        # Safe fallback: attach the note immediately before the first closing section after the pricing ladder.
        anchor='24.900 TL'
        pos=t.find(anchor)
        if pos<0: raise PatchError('surec: pricing ladder not found for 48h note')
        end=t.find('</section>',pos)
        if end<0: raise PatchError('surec: pricing section close missing')
        t=t[:end]+note+t[end:]
    print('surec 48h scope note patched')
else: print('surec 48h scope note already applied')

# Add a separate, idempotent attribution script rather than rewriting existing JS.
marker='data-synapse-readiness-attribution="v1"'
if marker not in t:
    script='''<script data-synapse-readiness-attribution="v1">(function(){var p=new URLSearchParams(location.search),d=document.getElementById('lead-tool'),e=document.getElementById('lead-result');if(d)d.value=(p.get('tool')||'').slice(0,80);if(e)e.value=(p.get('result')||'').slice(0,120);})();</script>'''
    if re.search(r'</body\s*>',t,re.I):
        t=re.sub(r'</body\s*>',script+'</body>',t,count=1,flags=re.I)
    else:
        t+=script
    print('surec attribution script patched')
else: print('surec attribution script already applied')
write(p,t,'surec analysis funnel')

# 5) sitemap.xml — append missing canonical URLs before closing urlset.
p,t=read('sitemap.xml')
urls=[
'araclar/site-ai-uyumluluk-taramasi.html','kanit/site-katalog-ai-hazirlik-metodolojisi.html','kanit/site-katalog-ai-hazirlik-ornek-rapor.html','rehberler/site-katalog-ai-hazirlik-rehberi.html','araclar/emlak-ai-surec-kontrol-listesi.html','rehberler/emlak-ai-otomasyon-hazirlik-rehberi.html','kanit/emlak-ai-3-sentetik-vaka.html',
'rehberler/ai-otomasyon-hazirlik-kontrolu.html','rehberler/ai-surec-denetimi.html','rehberler/workflow-hazirlik-hesaplayici.html','rehberler/site-ai-hazirlik.html','rehberler/katalog-ai-hazirlik.html','rehberler/prompt-injection-is-akisi-kontrolu.html','rehberler/ai-data-provenance.html','rehberler/eski-fiyat-stok-ai-riski.html','rehberler/ai-tool-yetki-sinirlari.html','rehberler/ai-insan-onayi-is-akisi.html']
missing=[]
for u in urls:
    loc=f'https://synapseautomate.github.io/{u}'
    if loc not in t: missing.append(f'<url><loc>{loc}</loc></url>')
if missing:
    if not re.search(r'</urlset\s*>',t,re.I): raise PatchError('sitemap: </urlset> missing')
    insert='\n'.join(missing)+'\n'
    t=re.sub(r'</urlset\s*>',insert+'</urlset>',t,count=1,flags=re.I)
    write(p,t,'sitemap discovery')
else: print('sitemap already applied')

# 6) llms.txt — append canonical discovery block once.
p,t=read('llms.txt')
block='''\n## Site & Katalog AI Hazırlık\n- Ücretsiz tarama: https://synapseautomate.github.io/araclar/site-ai-uyumluluk-taramasi.html\n- Metodoloji: https://synapseautomate.github.io/kanit/site-katalog-ai-hazirlik-metodolojisi.html\n- Sentetik örnek rapor: https://synapseautomate.github.io/kanit/site-katalog-ai-hazirlik-ornek-rapor.html\n- Emlak hazırlık rehberi: https://synapseautomate.github.io/rehberler/emlak-ai-otomasyon-hazirlik-rehberi.html\n- Sınır: hazırlık taraması bir AI görünürlük/sıralama, üretim doğruluğu veya güvenlik garantisi değildir.\n'''
if '## Site & Katalog AI Hazırlık' not in t:
    t=t.rstrip()+block+'\n'
    write(p,t,'llms discovery')
else: print('llms already applied')

print('READINESS FUNNEL PATCH PASS')
