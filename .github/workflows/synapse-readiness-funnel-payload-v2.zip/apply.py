from pathlib import Path
import shutil, sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
here=Path(__file__).parent
files=here/'files'
count=0
for src in files.rglob('*'):
    if not src.is_file(): continue
    rel=src.relative_to(files); dst=root/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst); count+=1
print(f'copied {count} customer/proof files')
# apply safe content patches
import subprocess
subprocess.run([sys.executable,str(here/'patch.py'),str(root)],check=True)
