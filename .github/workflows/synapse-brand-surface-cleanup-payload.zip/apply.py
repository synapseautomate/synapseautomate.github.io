from pathlib import Path
import json, hashlib, shutil, sys
repo=Path(sys.argv[1]).resolve(); here=Path(__file__).resolve().parent
manifest=json.loads((here/'manifest.json').read_text(encoding='utf-8'))
for rel,want in manifest.items():
    src=here/'files'/rel
    if hashlib.sha256(src.read_bytes()).hexdigest()!=want: raise SystemExit(f'payload hash mismatch: {rel}')
    dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
for rel in json.loads((here/'delete.json').read_text(encoding='utf-8')):
    p=repo/rel
    if p.is_file() or p.is_symlink(): p.unlink()
for name in ['D02','D03','D05','D06','D07','D08','D10','D11','D13']:
    p=repo/name
    if p.exists() and p.is_dir(): shutil.rmtree(p)
print(f'PASS: applied {len(manifest)} public-surface replacements and cleanup deletes')
