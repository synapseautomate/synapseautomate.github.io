from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import subprocess, sys, re
repo=Path(sys.argv[1]).resolve(); errors=[]
def run(cmd,cwd=None):
    p=subprocess.run(cmd,cwd=cwd or repo,text=True,capture_output=True)
    print('+',' '.join(map(str,cmd)))
    if p.stdout: print(p.stdout[-1800:])
    if p.returncode: errors.append('CMD FAIL '+' '.join(map(str,cmd))+'\n'+(p.stdout+p.stderr)[-2200:])
for name in ['D02','D03','D05','D06','D07','D08','D10','D11','D13']:
    if (repo/name).exists(): errors.append('internal public directory remains: '+name)
if (repo/'SYNAPSE_D03_NAV_FUNCTION_FIX_V1.zip').exists(): errors.append('obsolete internal zip remains')
prohibited=re.compile(r'(?i)(\bDay\s?(?:5|10|11|12|13)\b|\bGün\s?(?:5|10|11|12|13)\b|day(?:5|10|11|12|13)|gun(?:5|10|11|12|13)|D(?:05|10|11|12|13)-\d+|Red Bull|owner[- ]?waiv|smoke[- ]?test|proof moat|Kullanıcı yalnız|Bu sayfada tek ücretli CTA|Mutlak güven iddiası kurma)')
for p in repo.rglob('*'):
    if not p.is_file() or '.git' in p.parts or '.github' in p.parts or 'scripts' in p.parts or 'assets' in p.parts: continue
    if p.suffix.lower() not in {'.html','.md','.txt','.json','.csv','.py'}: continue
    try: t=p.read_text(encoding='utf-8',errors='ignore')
    except Exception: continue
    m=prohibited.search(t)
    if m: errors.append(f'internal/public-language leak: {p.relative_to(repo)} -> {m.group(0)}')
new=['veri/workflow-opportunity-inventory-public.csv','veri/workflow-opportunity-methodology.md','veri/workflow-opportunity-scorecard.csv']
old=['veri/gun4-workflow-inventory-public.csv','veri/gun4-workflow-opportunity-methodology.md','veri/gun4-opportunity-scorecard.csv','veri/gun4-workflow-inventory.csv','veri/gun4-scoreboard.json','veri/gun5-scoreboard.json','veri/gun6-scoreboard.json']
for rel in new:
    if not (repo/rel).exists(): errors.append('missing neutral public data: '+rel)
for rel in old:
    if (repo/rel).exists(): errors.append('old day-labelled public data remains: '+rel)
checks={
 'kaynaklar.html':['Yeni public proof · 2026 Reliability Test','100-vaka AI güvenilirlik regresyonu'],
 'rehberler/e-ticaret-ai-otomasyon-guvenlik-rehberi.html':['Test kapsamı ve sınırlamalar açıkça yayınlanır.'],
 'araclar/e-ticaret-ai-risk-kontrol-listesi.html':['Test kapsamı ve sınırlamalar açıkça yayınlanır.'],
 'cozumler/roofing-ev-hizmetleri.html':['Başlangıç kapsamı','İlk adım Süreç Analizi’dir.'],
 'public-proof/reliability-regression-v1/README.md':['Reliability Regression v1'],
}
for rel,need in checks.items():
    p=repo/rel
    if not p.exists(): errors.append('missing public page: '+rel); continue
    t=p.read_text(encoding='utf-8',errors='ignore')
    for s in need:
        if s not in t: errors.append(f'copy check missing in {rel}: {s}')
run(['python3','public-proof/reliability-regression-v1/run_regression.py','public-proof/reliability-regression-v1/test_cases.csv'])
run(['python3','run_mutation_checks.py','mutation_checks.csv'],cwd=repo/'public-proof/reliability-regression-v1')
run(['python3','public-proof/reliability-regression-v2/run_regression.py','public-proof/reliability-regression-v2/cases.csv'])
run(['python3','public-proof/structured-extraction-v1/validate.py'])
run(['python3','public-proof/structured-extraction-v1/test_ingest.py'])
run(['python3','public-proof/provenance-50-v1/validate.py'])
run(['python3','public-proof/human-approval/validate_rules.py'])
run(['python3','public-proof/workflow-output-schema-v2/validate.py'])
class P(HTMLParser):
    def __init__(self): super().__init__(); self.urls=[]
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        if tag in {'a','link'} and d.get('href'): self.urls.append(d['href'])
        if tag in {'img','script'} and d.get('src'): self.urls.append(d['src'])
missing=[]; checked=0
for f in repo.rglob('*.html'):
    if '.git' in f.parts: continue
    p=P();
    try: p.feed(f.read_text(encoding='utf-8',errors='ignore'))
    except Exception as e: errors.append(f'html parse error {f.relative_to(repo)}: {e}'); continue
    for raw in p.urls:
        if not raw or raw.startswith(('#','mailto:','tel:','javascript:','data:')): continue
        u=urlsplit(raw)
        if u.scheme or u.netloc: continue
        if not u.path: continue
        checked+=1
        target=(repo/u.path.lstrip('/')) if u.path.startswith('/') else (f.parent/u.path)
        target=target.resolve()
        try: target.relative_to(repo)
        except Exception: continue
        if target.is_dir(): target=target/'index.html'
        if not target.exists(): missing.append((str(f.relative_to(repo)),raw))
if missing:
    for item in missing[:25]: errors.append('broken internal link: '+repr(item))
print(f'LINK QA: checked={checked} missing={len(missing)}')
secret=re.compile(r'(?i)(api[_-]?key\s*[:=]\s*[A-Za-z0-9_-]{16,}|ghp_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{20,})')
for p in repo.rglob('*'):
    if not p.is_file() or '.git' in p.parts: continue
    if p.suffix.lower() not in {'.html','.md','.txt','.json','.csv','.py','.js','.yml','.yaml'}: continue
    try: t=p.read_text(encoding='utf-8',errors='ignore')
    except Exception: continue
    if secret.search(t): errors.append('possible secret: '+str(p.relative_to(repo)))
if (repo/'.git').exists(): run(['git','diff','--check'])
if errors:
    print('BRAND SURFACE QA FAIL'); [print('-',e) for e in errors]; raise SystemExit(1)
print('PASS: brand-surface cleanup quality gate')
print('internal execution artifacts removed; public day labels removed; links/proofs/regressions PASS')
