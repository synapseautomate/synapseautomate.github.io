from pathlib import Path
import json, hashlib, sys
repo=Path(sys.argv[1]).resolve(); here=Path(__file__).resolve().parent
base=json.loads((here/'baseline.json').read_text(encoding='utf-8'))
errors=[]
for rel,want in base.items():
    p=repo/rel
    if want is None:
        if p.exists(): errors.append(f'unexpected baseline file: {rel}')
        continue
    if not p.exists(): errors.append(f'missing baseline file: {rel}'); continue
    if hashlib.sha256(p.read_bytes()).hexdigest()!=want: errors.append(f'baseline hash mismatch: {rel}')
# Roofing is deliberately semantic-guarded: preserve any legitimate live edits and patch only known internal copy.
roof=repo/'cozumler/roofing-ev-hizmetleri.html'
if not roof.exists():
    errors.append('missing public page: cozumler/roofing-ev-hizmetleri.html')
else:
    t=roof.read_text(encoding='utf-8',errors='ignore')
    fingerprints=[
        'Ev Hizmetleri / Roofing AI Otomasyonu | Synapse Automate',
        'Talebi kaçırmadan nitelendir; fiyat ve taahhüdü insanda tut.',
        'Bu çözüm yalnız roofing şirketleri için mi?',
        'Süreç Analizi İste'
    ]
    for s in fingerprints:
        if s not in t: errors.append('roofing semantic fingerprint missing: '+s)
for rel in ['veri/workflow-opportunity-inventory-public.csv','veri/workflow-opportunity-methodology.md','veri/workflow-opportunity-scorecard.csv']:
    if (repo/rel).exists(): errors.append(f'neutral asset already exists: {rel}')
if errors:
    print('BRAND CLEANUP PREFLIGHT FAIL'); [print('-',e) for e in errors]; raise SystemExit(21)
print('PASS: exact baseline for protected assets + semantic guard for roofing page')
