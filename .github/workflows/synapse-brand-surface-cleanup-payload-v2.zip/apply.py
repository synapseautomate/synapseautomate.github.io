from pathlib import Path
import json, hashlib, shutil, sys
repo=Path(sys.argv[1]).resolve(); here=Path(__file__).resolve().parent
manifest=json.loads((here/'manifest.json').read_text(encoding='utf-8'))
for rel,want in manifest.items():
    src=here/'files'/rel
    if hashlib.sha256(src.read_bytes()).hexdigest()!=want: raise SystemExit(f'payload hash mismatch: {rel}')
    dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
# Preserve live roofing edits; remove only known internal production language / day-labelled attribution.
roof=repo/'cozumler/roofing-ev-hizmetleri.html'
t=roof.read_text(encoding='utf-8')
t=t.replace('src=day10-offer','src=proof-offer')
t=t.replace('<div class="card"><h2>Tek ticari yol</h2><p>Bu sayfada tek ücretli CTA vardır: Süreç Analizi. Pilot veya daha geniş kapsam, analiz sonucuna göre ayrı tanımlanır.</p></div>',
            '<div class="card"><h2>Başlangıç kapsamı</h2><p>İlk adım Süreç Analizi’dir. Pilot veya daha geniş kapsam, analiz sonucuna göre ayrı tanımlanır.</p></div>')
t=t.replace('Bu sayfada tek ücretli CTA vardır: Süreç Analizi. Pilot veya daha geniş kapsam, analiz sonucuna göre ayrı tanımlanır.',
            'İlk adım Süreç Analizi’dir. Pilot veya daha geniş kapsam, analiz sonucuna göre ayrı tanımlanır.')
t=t.replace('<h2>Tek ticari yol</h2>','<h2>Başlangıç kapsamı</h2>')
roof.write_text(t,encoding='utf-8')
for rel in json.loads((here/'delete.json').read_text(encoding='utf-8')):
    p=repo/rel
    if p.is_file() or p.is_symlink(): p.unlink()
for name in ['D02','D03','D05','D06','D07','D08','D10','D11','D13']:
    p=repo/name
    if p.exists() and p.is_dir(): shutil.rmtree(p)
print(f'PASS: applied {len(manifest)} replacements + semantic roofing cleanup + cleanup deletes')
