#!/usr/bin/env python3
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET

ROOT=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
SITE='https://synapseautomate.github.io'


def fail(m):
    print('D03 ROOT FIX FAIL:',m)
    raise SystemExit(2)

def relprefix(p):
    depth=len(p.relative_to(ROOT).parts)-1
    return '../'*depth

required=[
 'index.html','hizmetler.html','urunler.html','sektorler.html','hakkimizda.html',
 'assets/styles-v33.css','assets/app-v33.js',
 'araclar/gelir-kacagi-hesaplayici.html','araclar/surec-hazirlik-skoru.html',
 'araclar/otomasyon-deger-hesaplayici.html','cozumler/musteri-talebi-surec-analizi.html',
 'cozumler/site-katalog-uyumlulugu.html','sektorler/dis-estetik-wellness.html',
 'araclar/site-ai-uyumluluk-taramasi.html','demolar/vela-saha-akisi.html',
 'sektorler/finans-bankacilik.html','assets/day3/day3.css'
]
for r in required:
    if not (ROOT/r).exists(): fail('required file missing: '+r)

# ---------- Day 3 mobile navigation + button styling ----------
cssp=ROOT/'assets/day3/day3.css'
css=cssp.read_text(encoding='utf-8')
marker='/* D03 navigation/function root fix */'
if marker not in css:
    css += r'''

/* D03 navigation/function root fix */
.menu-button-day3{display:none;align-items:center;justify-content:center;width:48px;height:48px;border-radius:14px;border:1px solid var(--line);background:#0a2032;color:var(--text);font:inherit;font-weight:900;cursor:pointer}
.navlinks .nav-cta-link{border:1px solid var(--teal);border-radius:12px;padding:8px 12px;color:var(--teal)}
.btn{cursor:pointer;transition:transform .16s ease,background .16s ease,border-color .16s ease,color .16s ease}
.btn:hover{transform:translateY(-1px)}
.btn:focus-visible,.menu-button-day3:focus-visible,.field input:focus-visible,.field textarea:focus-visible,.field select:focus-visible{outline:3px solid rgba(82,229,213,.35);outline-offset:3px}
.btn.secondary{background:#0a2032;color:#f3f8fb;border-color:#52e5d5;appearance:none;-webkit-appearance:none}
.btn.secondary:hover{background:#12314b;color:#fff}
.btn.secondary.is-handoff{border-color:var(--amber);color:#ffe0a0}
.inline-status{margin-top:14px;padding:13px 15px;border:1px solid var(--line);border-radius:12px;background:#071827;color:#c8d7e1}
.inline-status.error{border-color:var(--danger);color:#ffd0cb}
.inline-status.success{border-color:var(--teal);color:#d7fff9}
.resource-link{color:var(--teal);font-weight:800;text-underline-offset:3px}
@media(max-width:860px){.nav{position:relative}.menu-button-day3{display:inline-flex}.navlinks{display:none;position:absolute;left:0;right:0;top:calc(100% + 14px);flex-direction:column;gap:0;padding:12px;border:1px solid var(--line);border-radius:18px;background:rgba(6,19,33,.99);box-shadow:0 24px 70px rgba(0,0,0,.38)}.navlinks.open{display:flex}.navlinks a{padding:13px 12px;border-radius:10px}.navlinks a:hover{background:#0d2940}.navlinks .nav-cta-link{margin-top:6px}}
'''
    cssp.write_text(css,encoding='utf-8')

js_path=ROOT/'assets/day3/day3.js'
js_path.write_text(r'''(() => {
  const button = document.querySelector('.menu-button-day3');
  const nav = document.querySelector('.navlinks');
  if (!button || !nav) return;
  const close = () => {
    nav.classList.remove('open');
    button.setAttribute('aria-expanded','false');
    button.setAttribute('aria-label','Menüyü aç');
  };
  button.addEventListener('click', () => {
    const open = !nav.classList.contains('open');
    nav.classList.toggle('open', open);
    button.setAttribute('aria-expanded', String(open));
    button.setAttribute('aria-label', open ? 'Menüyü kapat' : 'Menüyü aç');
  });
  nav.querySelectorAll('a').forEach(a => a.addEventListener('click', close));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  document.addEventListener('click', e => {
    if (!nav.classList.contains('open')) return;
    if (!nav.contains(e.target) && !button.contains(e.target)) close();
  });
})();
''',encoding='utf-8')

# Day 3 custom-shell pages
D3=[
 'araclar/etkilesimli-teklif-sablonu.html','araclar/finans-surec-kontrol-listesi.html',
 'araclar/kreatif-fikir-mini-formu.html','araclar/site-ai-uyumluluk-taramasi.html',
 'demolar/vela-saha-akisi.html','kanit/ai-otomasyon-kanit-metodolojisi.html',
 'rehberler/ai-otomasyonunda-insan-onayi.html','rehberler/finans-ai-otomasyonu-guvenli-baslangic.html',
 'sektorler/finans-bankacilik.html'
]
header='''<header><div class="wrap nav"><a class="brand" href="/" aria-label="Synapse Automate ana sayfa"><img src="/assets/brand/synapse-logo-clean.png" alt="Synapse Automate"></a><button class="menu-button-day3" type="button" aria-label="Menüyü aç" aria-expanded="false" aria-controls="day3-nav">☰</button><nav class="navlinks" id="day3-nav" aria-label="Ana navigasyon"><a href="/">Ana Sayfa</a><a href="/hizmetler.html">Hizmetler</a><a href="/urunler.html">Çözümler</a><a href="/sektorler.html">Sektörler</a><a href="/kaynaklar.html">Kaynak Merkezi</a><a href="/hakkimizda.html">Hakkımızda</a><a class="nav-cta-link" href="/surec-analizi.html">Süreç Analizi İste</a></nav></div></header>'''
for rel in D3:
    p=ROOT/rel
    if not p.exists(): fail('D3 page missing: '+rel)
    s=p.read_text(encoding='utf-8')
    s=re.sub(r'<header>.*?</header>',header,s,flags=re.S,count=1)
    if '/assets/day3/day3.js' not in s:
        s=s.replace('</body>','<script defer src="/assets/day3/day3.js"></script></body>')
    p.write_text(s,encoding='utf-8')

# ---------- Scanner: explicit validation + honest client-side result ----------
p=ROOT/'araclar/site-ai-uyumluluk-taramasi.html'
s=p.read_text(encoding='utf-8')
s=s.replace('id="scan"><div class="field"','id="scan" novalidate><div class="field"')
s=s.replace('id="url" type="url" placeholder="https://..." required','id="url" type="url" inputmode="url" autocomplete="url" placeholder="https://ornek.com/sayfa"')
new_scan=r'''<script>
(() => {
  const form=document.getElementById('scan'), input=document.getElementById('url'), out=document.getElementById('scanout');
  form.addEventListener('submit', e => {
    e.preventDefault();
    const raw=input.value.trim();
    if(!raw){out.className='result inline-status error';out.innerHTML='<strong>URL gerekli.</strong><p>Örnek taramayı çalıştırmak için bir sayfa veya site URL’si girin. Bu demo uzak siteye veri göndermez.</p>';input.focus();return;}
    let parsed;
    try{parsed=new URL(raw);}catch(err){out.className='result inline-status error';out.innerHTML='<strong>URL biçimi geçerli değil.</strong><p>Adres https:// ile başlamalıdır. Örnek: https://ornek.com/hizmet</p>';input.focus();return;}
    if(!['http:','https:'].includes(parsed.protocol)){out.className='result inline-status error';out.innerHTML='<strong>Web adresi gerekli.</strong><p>Yalnız http veya https adresleri kabul edilir.</p>';return;}
    out.className='result inline-status success';
    out.innerHTML='<strong>Örnek rapor formatı hazır.</strong><p><b>Adres:</b> '+parsed.hostname+'</p><p>Bu statik demo uzak siteyi taradığını iddia etmez. Gerçek analizde 7 kategori için kanıt URL’leri, 0–100 hazırlık skoru, kırmızı/sarı/yeşil bulgular ve düzeltme önceliği üretilir.</p><a class="btn primary" href="/surec-analizi.html">Gerçek tarama iste</a>';
  });
})();
</script>'''
s=re.sub(r"<script>document\.getElementById\('scan'\).*?</script>",new_scan,s,flags=re.S,count=1)
p.write_text(s,encoding='utf-8')

# ---------- VELA: secondary buttons visible + functional + no fake external action ----------
p=ROOT/'demolar/vela-saha-akisi.html'
s=p.read_text(encoding='utf-8')
new_vela=r'''<script>
(() => {
  const run=document.getElementById('run'), out=document.getElementById('velaout'), note=document.getElementById('note');
  run.addEventListener('click', () => {
    out.innerHTML='<p><b>Müşteri:</b> Atlas Fotoğraf</p><p><b>Kalem:</b> Ürün çekimi</p><p><b>Miktar:</b> 12</p><p><b>Termin:</b> Cuma</p><p><b>Fiyat:</b> <span style="color:#f2b34e">bilinmiyor — insan gerekli</span></p><p><b>Uyarı:</b> Fiyat kaynağı olmadan teklif gönderilemez.</p><div class="btns"><button id="edit-note" class="btn secondary" type="button">Düzenle</button><button id="handoff" class="btn secondary is-handoff" type="button">İnsana devret (demo)</button></div><div id="vela-status" class="inline-status">Demo durumu: insan onayı bekleniyor.</div>';
    document.getElementById('edit-note').addEventListener('click', () => {note.focus();note.setSelectionRange(note.value.length,note.value.length);document.getElementById('vela-status').textContent='Düzenleme modu açıldı. Notu değiştirip “Akışı çalıştır” ile yeniden değerlendirin.';note.scrollIntoView({behavior:'smooth',block:'center'});});
    document.getElementById('handoff').addEventListener('click', () => {const st=document.getElementById('vela-status');st.className='inline-status success';st.innerHTML='<strong>İnsan devri durumu oluşturuldu.</strong><p>Bu statik demo dış sisteme mesaj göndermez. Gerçek uygulamada kayıt, bağlam ve onay yetkili kişiye aktarılır.</p><a class="resource-link" href="/surec-analizi.html">Bu akışı kendi süreciniz için inceletin →</a>';});
  });
})();
</script>'''
s=re.sub(r"<script>document\.getElementById\('run'\).*?</script>",new_vela,s,flags=re.S,count=1)
p.write_text(s,encoding='utf-8')

# ---------- Creative form: visible validation + HTML injection safety ----------
p=ROOT/'araclar/kreatif-fikir-mini-formu.html'
s=p.read_text(encoding='utf-8')
new_creative=r'''<script>
(() => {
  const form=document.getElementById('creative'), out=document.getElementById('creativeout');
  const esc=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  form.addEventListener('submit', e => {
    e.preventDefault();
    const p=document.getElementById('prod').value.trim(),a=document.getElementById('aud').value.trim(),f=document.getElementById('fact').value.trim();
    if(!p||!a||!f){out.className='result inline-status error';out.textContent='Üç alanı da doldurun; yalnız doğrulanmış gerçek kullanın.';return;}
    out.className='result inline-status success';out.innerHTML='<strong>3 güvenli açı</strong><ol><li><b>Sorun:</b> '+esc(a)+' için '+esc(p)+' öncesindeki görünmeyen sürtünmeyi anlat; kanıt: '+esc(f)+'</li><li><b>Mekanizma:</b> girdi → kural → insan onayı → ölçüm akışını görselleştir.</li><li><b>Kanıt:</b> doğrulanmış gerçeği yöntem + sınır + tek CTA ile yayınla.</li></ol>';
  });
})();
</script>'''
s=re.sub(r"<script>document\.getElementById\('creative'\).*?</script>",new_creative,s,flags=re.S,count=1)
p.write_text(s,encoding='utf-8')

# ---------- Resource Center: D02 + D03 discovery ----------
hub=r'''<!doctype html><html lang="tr" class="no-js"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>Kaynak Merkezi | Synapse Automate</title><meta name="description" content="Synapse Automate ücretsiz araçları, kurumsal AI rehberleri, kontrollü demoları ve kanıt metodolojileri."><meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"><meta name="theme-color" content="#06111f"><link rel="stylesheet" href="assets/styles-v33.css"><link rel="canonical" href="https://synapseautomate.github.io/kaynaklar.html"></head><body><a class="skip" href="#main">İçeriğe geç</a><div class="progress" aria-hidden="true"></div><header class="site-header"><div class="container nav"><a class="brand" href="index.html" aria-label="Synapse Automate ana sayfa"><img src="assets/brand/synapse-logo-clean.png" alt="Synapse Automate"></a><button class="menu-button" aria-label="Menüyü aç" aria-expanded="false">☰</button><nav class="nav-links" aria-label="Ana menü"><a href="hizmetler.html">Hizmetler</a><a href="urunler.html">Çözümler</a><a href="sektorler.html">Sektörler</a><a href="kaynaklar.html" aria-current="page">Kaynak Merkezi</a><a href="hakkimizda.html">Hakkımızda</a></nav><a class="nav-cta" href="surec-analizi.html">Süreç Analizi İste</a></div></header><main id="main"><section class="page-hero"><div class="container"><div class="kicker">Kaynak Merkezi</div><h1>Önce görünür kanıt. Sonra otomasyon.</h1><p class="lead">Ücretsiz araçlar, rehberler, kontrollü demolar ve metodoloji sayfaları tek merkezde. Her varlık kaynak, sınır, insan onayı ve ölçüm prensibiyle tasarlanır.</p></div></section><section id="araclar" class="section"><div class="container"><div class="section-head"><div><div class="kicker">Ücretsiz araçlar</div><h2>Mevcut durumu ölçmeden çözüm seçmeyin.</h2></div></div><div class="grid grid-3"><article class="card"><h3>Müşteri Talebi Kayıp Hesaplayıcısı</h3><p>Talep kaybı varsayımlarını görünür yapın.</p><a class="more" href="araclar/gelir-kacagi-hesaplayici.html">Aracı aç</a></article><article class="card"><h3>Süreç Hazırlık Skoru</h3><p>Veri, kaynak, insan onayı ve ölçüm hazırlığını kontrol edin.</p><a class="more" href="araclar/surec-hazirlik-skoru.html">Aracı aç</a></article><article class="card"><h3>Operasyon Değeri Hesaplayıcısı</h3><p>Varsayımları açık tutarak operasyon senaryosu oluşturun.</p><a class="more" href="araclar/otomasyon-deger-hesaplayici.html">Aracı aç</a></article><article class="card"><h3>Site &amp; Katalog AI Uyumluluğu</h3><p>7 kategoride doğrulanabilirlik boşluklarını görün.</p><a class="more" href="araclar/site-ai-uyumluluk-taramasi.html">Örnek taramayı aç</a></article><article class="card"><h3>Finans Süreç Kontrol Listesi</h3><p>Kaynak, kural, insan onayı ve veri sınırlarını 8 adımda kontrol edin.</p><a class="more" href="araclar/finans-surec-kontrol-listesi.html">Kontrol listesini aç</a></article><article class="card"><h3>Kreatif Fikir Mini Formu</h3><p>Doğrulanmış tek bir gerçekten güvenli içerik açıları üretin.</p><a class="more" href="araclar/kreatif-fikir-mini-formu.html">Mini formu aç</a></article></div></div></section><section id="rehberler" class="section"><div class="container"><div class="section-head"><div><div class="kicker">Rehberler</div><h2>Karar vericiler için açık, kaynaklı anlatım.</h2></div></div><div class="grid grid-3"><article class="card"><h3>Kurumsal AI Otomasyonu</h3><a class="more" href="rehberler/kurumsal-ai-otomasyonu.html">Rehberi oku</a></article><article class="card"><h3>AI Otomasyonunda İnsan Onayı</h3><a class="more" href="rehberler/ai-otomasyonunda-insan-onayi.html">Rehberi oku</a></article><article class="card"><h3>Finans AI Otomasyonuna Güvenli Başlangıç</h3><a class="more" href="rehberler/finans-ai-otomasyonu-guvenli-baslangic.html">Rehberi oku</a></article><article class="card"><h3>Roofing / Ev Hizmetleri Talep Yönetimi</h3><a class="more" href="rehberler/roofing-lead-yonetimi.html">Rehberi oku</a></article><article class="card"><h3>AI Pilot Başarı Ölçümü</h3><a class="more" href="rehberler/ai-pilot-kpi.html">Rehberi oku</a></article></div></div></section><section id="demolar" class="section"><div class="container"><div class="section-head"><div><div class="kicker">Demo &amp; kanıt</div><h2>İddia yerine kontrollü davranış gösterin.</h2></div></div><div class="grid grid-3"><article class="card"><h3>VELA Kontrollü Saha Akışı</h3><p>Metin → yapılandırma → doğrulama → insan onayı.</p><a class="more" href="demolar/vela-saha-akisi.html">Demoyu aç</a></article><article class="card"><h3>AI Otomasyon Kanıt Metodolojisi</h3><p>Test, kaynak ve güven sınırlarının nasıl raporlandığını görün.</p><a class="more" href="kanit/ai-otomasyon-kanit-metodolojisi.html">Metodolojiyi incele</a></article><article class="card"><h3>Site &amp; Katalog Hazırlık Analizi</h3><p>Ürün ve hizmet gerçeklerini kanıt zinciriyle değerlendirin.</p><a class="more" href="cozumler/site-katalog-uyumlulugu.html">Çözümü incele</a></article></div></div></section><section class="section-tight"><div class="container"><div class="featured"><div><div class="kicker">Tek sonraki adım</div><h2>Kendi sürecinizde kayıp noktalarını görün.</h2><p class="lead">Önce süreç, kaynak ve insan onayı sınırlarını çıkarın; yalnız sonra uygulama kararı verin.</p></div><a class="btn btn-primary" href="surec-analizi.html">Süreç Analizi İste</a></div></div></section></main><footer class="footer"><div class="container"><div class="footer-grid"><div><a class="brand" href="index.html"><img src="assets/brand/synapse-logo-clean.png" alt="Synapse Automate"></a><p style="color:#8fa8b8;max-width:370px">Şirketlerin tekrar eden işlerini daha hızlı, ölçülebilir ve insan denetimli dijital süreçlere dönüştürüyoruz.</p></div><div><h4>Çözümler</h4><a href="urunler/revenueos.html">Müşteri Talebi ve Satış Takibi</a><a href="sektorler.html">Sektör Çözümleri</a><a href="hizmetler.html">Kurumsal Hizmetler</a></div><div><h4>Kurumsal</h4><a href="hakkimizda.html">Hakkımızda</a><a href="kinetra-group.html">Kinetra Group</a><a href="kinetra-studios.html">Kinetra Studios</a></div><div><h4>Kaynaklar</h4><a href="kaynaklar.html">Kaynak Merkezi</a><a href="kaynaklar.html#araclar">Ücretsiz Araçlar</a><a href="kaynaklar.html#rehberler">Rehberler</a><a href="gizlilik.html">Gizlilik</a></div></div><div class="copyright"><span>© 2026 Synapse Automate. Tüm hakları saklıdır.</span><span>Kinetra Group çatısı altında planlanan yapay zekâ odaklı teknoloji yapısı.</span></div></div></footer><script defer src="assets/app-v33.js"></script></body></html>'''
(ROOT/'kaynaklar.html').write_text(hub,encoding='utf-8')

# ---------- Global V3.3 navigation + footer ----------
for p in ROOT.rglob('*.html'):
    rel=p.relative_to(ROOT).as_posix()
    if rel.startswith('.github/') or rel.startswith('D0'): continue
    try:s=p.read_text(encoding='utf-8')
    except Exception:continue
    pre=relprefix(p)
    if 'class="nav-links"' in s:
        nav=f'<nav class="nav-links" aria-label="Ana menü"><a href="{pre}hizmetler.html">Hizmetler</a><a href="{pre}urunler.html">Çözümler</a><a href="{pre}sektorler.html">Sektörler</a><a href="{pre}kaynaklar.html">Kaynak Merkezi</a><a href="{pre}hakkimizda.html">Hakkımızda</a></nav>'
        s=re.sub(r'<nav class="nav-links"[^>]*>.*?</nav>',nav,s,flags=re.S,count=1)
    if '<h4>Kaynaklar</h4>' in s:
        fres=f'<div><h4>Kaynaklar</h4><a href="{pre}kaynaklar.html">Kaynak Merkezi</a><a href="{pre}kaynaklar.html#araclar">Ücretsiz Araçlar</a><a href="{pre}kaynaklar.html#rehberler">Rehberler</a><a href="{pre}gizlilik.html">Gizlilik</a></div>'
        s=re.sub(r'<div><h4>Kaynaklar</h4>.*?</div>',fres,s,flags=re.S,count=1)
    p.write_text(s,encoding='utf-8')

idx=ROOT/'index.html'
s=idx.read_text(encoding='utf-8')
if 'D03-RESOURCE-DISCOVERY' not in s and '</main>' in s:
    block='''<!-- D03-RESOURCE-DISCOVERY --><section class="section-tight"><div class="container"><div class="featured"><div><div class="kicker">Kaynak Merkezi</div><h2>Ücretsiz araçlar, rehberler ve kontrollü demolar.</h2><p class="lead">Müşteri talebi, süreç hazırlığı, site/katalog doğrulanabilirliği, finans güven sınırları ve insan onayı için yayınlanmış kaynaklara tek yerden ulaşın.</p></div><a class="btn btn-primary" href="kaynaklar.html">Kaynak Merkezi'ni Aç</a></div></div></section>'''
    s=s.replace('</main>',block+'</main>',1)
    idx.write_text(s,encoding='utf-8')

# ---------- Sitemap ----------
ns='http://www.sitemaps.org/schemas/sitemap/0.9'
ET.register_namespace('',ns)
root=ET.Element('{%s}urlset'%ns)
for p in sorted(ROOT.rglob('*.html')):
    rel=p.relative_to(ROOT).as_posix()
    if rel.startswith('.github/') or rel.startswith('D0') or rel.startswith('_') or rel=='404.html':continue
    u=SITE+'/' + ('' if rel=='index.html' else rel)
    e=ET.SubElement(root,'{%s}url'%ns);ET.SubElement(e,'{%s}loc'%ns).text=u;ET.SubElement(e,'{%s}lastmod'%ns).text='2026-08-06'
ET.ElementTree(root).write(ROOT/'sitemap.xml',encoding='utf-8',xml_declaration=True)
print('D03 ROOT FIX APPLY: PASS')
