#!/usr/bin/env python3
from pathlib import Path
import re, sys, html as htmlmod
ROOT=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errors=[]
def err(m):errors.append(m)
day2=['sektorler/dis-estetik-wellness.html','araclar/gelir-kacagi-hesaplayici.html','araclar/surec-hazirlik-skoru.html','araclar/otomasyon-deger-hesaplayici.html','cozumler/musteri-talebi-surec-analizi.html','cozumler/site-katalog-uyumlulugu.html']
day3=['sektorler/finans-bankacilik.html','araclar/finans-surec-kontrol-listesi.html','araclar/site-ai-uyumluluk-taramasi.html','araclar/etkilesimli-teklif-sablonu.html','araclar/kreatif-fikir-mini-formu.html','demolar/vela-saha-akisi.html','kanit/ai-otomasyon-kanit-metodolojisi.html','rehberler/ai-otomasyonunda-insan-onayi.html','rehberler/finans-ai-otomasyonu-guvenli-baslangic.html']
for r in ['kaynaklar.html']+day2+day3:
    if not (ROOT/r).exists():err('missing public asset: '+r)
hub=(ROOT/'kaynaklar.html').read_text(encoding='utf-8')
for r in [x for x in day2+day3 if not x.startswith('sektorler/')]:
    if r not in hub:err('resource hub missing link: '+r)
sec=(ROOT/'sektorler.html').read_text(encoding='utf-8')
if 'dis-estetik-wellness.html' not in sec:err('sector directory missing Dental/Wellness link')
if 'finans-bankacilik.html' not in sec:err('sector directory missing Finance link')
idx=(ROOT/'index.html').read_text(encoding='utf-8')
if 'kaynaklar.html' not in idx:err('homepage does not expose Resource Center')
if 'D03-RESOURCE-DISCOVERY' not in idx:err('homepage resource discovery block missing')
for r in day3:
    s=(ROOT/r).read_text(encoding='utf-8')
    if 'menu-button-day3' not in s:err(r+' missing mobile menu button')
    if '/kaynaklar.html' not in s:err(r+' missing Resource Center')
    if '/assets/day3/day3.js' not in s:err(r+' missing mobile menu JS')
css=(ROOT/'assets/day3/day3.css').read_text(encoding='utf-8')
for t in ['.btn.secondary{','background:#0a2032','menu-button-day3','.navlinks.open']:
    if t not in css:err('day3 css missing '+t)
scan=(ROOT/'araclar/site-ai-uyumluluk-taramasi.html').read_text(encoding='utf-8')
for t in ['URL gerekli.','new URL(raw)','Örnek rapor formatı hazır']:
    if t not in scan:err('scanner interaction missing '+t)
vela=(ROOT/'demolar/vela-saha-akisi.html').read_text(encoding='utf-8')
for t in ['edit-note','handoff','İnsan devri durumu oluşturuldu','dış sisteme mesaj göndermez']:
    if t not in vela:err('VELA interaction missing '+t)
# Broken internal links
for p in ROOT.rglob('*.html'):
    rel=p.relative_to(ROOT).as_posix()
    if rel.startswith('.github/') or rel.startswith('D0'):continue
    s=p.read_text(encoding='utf-8')
    for href in re.findall(r'href=["\']([^"\']+)["\']',s,re.I):
        href=htmlmod.unescape(href).strip()
        if not href or href.startswith(('#','mailto:','tel:','javascript:','https://','http://')):continue
        target=href.split('#',1)[0].split('?',1)[0]
        if not target:continue
        if target=='/':q=ROOT/'index.html'
        elif target.startswith('/'):q=ROOT/target.lstrip('/')
        else:q=(p.parent/target).resolve()
        if q.is_dir():q=q/'index.html'
        if not q.exists():err(f'broken internal link: {rel} -> {href}')
if errors:
    print('D03 ROOT FIX QA: FAIL')
    for x in errors:print('-',x)
    raise SystemExit(1)
print('D03 ROOT FIX QA: PASS')
print('D02 assets checked:',len(day2))
print('D03 assets checked:',len(day3))
print('Discovery path: homepage -> Kaynak Merkezi -> public assets')
