#!/usr/bin/env python3
from pathlib import Path
import shutil, re, json, xml.etree.ElementTree as ET
from datetime import date
import sys

repo=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
pkg=Path(__file__).resolve().parent
payload=pkg/'payload'
brand=pkg/'assets'/'brand'/'synapse-logo-clean.png'
TODAY='2026-08-06'
SITE='https://synapseautomate.github.io'

# copy payload, but preserve an existing process-analysis page if it is richer than fallback
for src in payload.rglob('*'):
    if not src.is_file(): continue
    rel=src.relative_to(payload)
    dest=repo/rel
    if rel.as_posix()=='surec-analizi.html' and dest.exists() and dest.stat().st_size>2500:
        continue
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dest)

# exact user-approved transparent logo
logo_dest=repo/'assets'/'brand'/'synapse-logo-clean.png'
logo_dest.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(brand,logo_dest)

# Finance page canonical alias policy: if a likely older finance page exists elsewhere, replace it with redirect only.
canonical='/sektorler/finans-bankacilik.html'
for cand in ['finans.html','finans-bankacilik.html','sektorler/finans.html']:
    p=repo/cand
    if p.exists() and p.as_posix()!=str(repo/canonical.lstrip('/')):
        p.write_text(f'''<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0; url={canonical}"><link rel="canonical" href="{SITE}{canonical}"><title>Finans & Bankacılık | Synapse Automate</title></head><body><p><a href="{canonical}">Finans & Bankacılık sayfasına git</a></p></body></html>''',encoding='utf-8')

# update any anchor whose visible text is Finans & Bankacılık to canonical, without touching unrelated links
for p in repo.rglob('*.html'):
    try: txt=p.read_text(encoding='utf-8')
    except Exception: continue
    new=re.sub(r'(<a\b[^>]*href=["\'])[^"\']*(["\'][^>]*>\s*Finans\s*&amp;\s*Bankacılık\s*</a>)',r'\1'+canonical+r'\2',txt,flags=re.I)
    new=re.sub(r'(<a\b[^>]*href=["\'])[^"\']*(["\'][^>]*>\s*Finans\s*&\s*Bankacılık\s*</a>)',r'\1'+canonical+r'\2',new,flags=re.I)
    if new!=txt: p.write_text(new,encoding='utf-8')

# robots: preserve unknown directives but ensure required search bot groups and sitemap
rp=repo/'robots.txt'
existing=rp.read_text(encoding='utf-8') if rp.exists() else ''
append='''\n# Day 3: search / AI retrieval access\nUser-agent: OAI-SearchBot\nAllow: /\n\nUser-agent: Claude-SearchBot\nAllow: /\n\nUser-agent: Claude-User\nAllow: /\n\nUser-agent: PerplexityBot\nAllow: /\n\n'''
if 'OAI-SearchBot' not in existing: existing+=append
if 'Sitemap: https://synapseautomate.github.io/sitemap.xml' not in existing:
    existing+='\nSitemap: https://synapseautomate.github.io/sitemap.xml\n'
rp.write_text(existing.strip()+"\n",encoding='utf-8')

# sitemap: merge canonical HTML URLs; don't delete anything
urls=[]
for p in repo.rglob('*.html'):
    rel=p.relative_to(repo).as_posix()
    if rel.startswith('.github/') or rel.startswith('D03/') or rel.startswith('_'): continue
    if rel=='404.html': continue
    url=SITE+'/' + ('' if rel=='index.html' else rel)
    urls.append(url)
urls=sorted(set(urls))
ns='http://www.sitemaps.org/schemas/sitemap/0.9'
ET.register_namespace('',ns)
root=ET.Element('{%s}urlset'%ns)
for u in urls:
    e=ET.SubElement(root,'{%s}url'%ns); ET.SubElement(e,'{%s}loc'%ns).text=u; ET.SubElement(e,'{%s}lastmod'%ns).text=TODAY
ET.ElementTree(root).write(repo/'sitemap.xml',encoding='utf-8',xml_declaration=True)

# runtime baseline report
htmls=list(repo.rglob('*.html'))
report={'date':TODAY,'html_count':len(htmls),'has_robots':(repo/'robots.txt').exists(),'has_sitemap':(repo/'sitemap.xml').exists(),'finance_page':(repo/'sektorler'/'finans-bankacilik.html').exists(),'tools':[str(p.relative_to(repo)) for p in (repo/'araclar').glob('*.html')] if (repo/'araclar').exists() else [],'notes':['Search Console/Bing ownership cannot be verified by CI without account access.','Indexed/search/AI citation metrics remain unknown until platform verification and live observation.']}
(repo/'D03').mkdir(exist_ok=True)
(repo/'D03'/'technical_baseline_runtime.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('DAY3 APPLY: PASS')
