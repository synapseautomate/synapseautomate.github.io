#!/usr/bin/env python3
from pathlib import Path
import json,re,sys,xml.etree.ElementTree as ET
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errors=[]
required=[
'sektorler/finans-bankacilik.html','araclar/finans-surec-kontrol-listesi.html','araclar/site-ai-uyumluluk-taramasi.html','araclar/kreatif-fikir-mini-formu.html','araclar/etkilesimli-teklif-sablonu.html','kanit/ai-otomasyon-kanit-metodolojisi.html','rehberler/finans-ai-otomasyonu-guvenli-baslangic.html','rehberler/ai-otomasyonunda-insan-onayi.html','demolar/vela-saha-akisi.html','bilgi.html','llms.txt','assets/brand/synapse-logo-clean.png','sitemap.xml','robots.txt']
for r in required:
    if not (repo/r).exists(): errors.append('missing '+r)
for r in [x for x in required if x.endswith('.html')]:
    p=repo/r; txt=p.read_text(encoding='utf-8') if p.exists() else ''
    for needle,label in [('<meta charset="utf-8"','utf8'),('name="viewport"','viewport'),('rel="canonical"','canonical'),('<h1','h1'),('synapse-logo-clean.png','logo')]:
        if needle.lower() not in txt.lower(): errors.append(f'{r}: missing {label}')
    if '\ufffd' in txt: errors.append(f'{r}: replacement character')
    if len(re.findall(r'<h1\b',txt,re.I))!=1: errors.append(f'{r}: h1 count')
    # every JSON-LD block must parse
    for s in re.findall(r'<script type="application/ld\+json">(.*?)</script>',txt,re.S|re.I):
        try: json.loads(s)
        except Exception as e: errors.append(f'{r}: schema parse {e}')
robots=(repo/'robots.txt').read_text(encoding='utf-8') if (repo/'robots.txt').exists() else ''
for bot in ['OAI-SearchBot','Claude-SearchBot','Claude-User','PerplexityBot']:
    if bot not in robots: errors.append('robots missing '+bot)
if (repo/'sitemap.xml').exists():
    try:
        root=ET.parse(repo/'sitemap.xml').getroot(); text=' '.join((e.text or '') for e in root.iter())
        for u in ['sektorler/finans-bankacilik.html','araclar/finans-surec-kontrol-listesi.html','kanit/ai-otomasyon-kanit-metodolojisi.html']:
            if u not in text: errors.append('sitemap missing '+u)
    except Exception as e: errors.append('sitemap parse '+str(e))
# no trailing whitespace in D03 / new payload files
for base in [repo/'D03',repo/'sektorler',repo/'araclar',repo/'rehberler',repo/'kanit',repo/'demolar']:
    if not base.exists(): continue
    for p in base.rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.html','.md','.csv','.json','.txt'}:
            try: lines=p.read_text(encoding='utf-8').splitlines()
            except: continue
            for i,l in enumerate(lines,1):
                if l.rstrip()!=l: errors.append(f'{p.relative_to(repo)}:{i} trailing whitespace'); break
if errors:
    print('DAY3 QA: FAIL')
    for e in errors: print('-',e)
    sys.exit(2)
print('DAY3 QA: PASS')
