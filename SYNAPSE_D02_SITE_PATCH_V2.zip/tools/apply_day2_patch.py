#!/usr/bin/env python3
from pathlib import Path
import shutil,re,sys
ROOT=Path('.')
PAY=Path('.d02_patch')

def fail(msg):
    print('D02 PATCH FAIL:',msg); raise SystemExit(2)

def read(p): return p.read_text(encoding='utf-8')
def write(p,s): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s,encoding='utf-8')
# Assert expected V3.3 base assets before touching content.
for req in ['index.html','sektorler.html','urunler/revenueos.html','assets/styles-v33.css','assets/app-v33.js','sitemap.xml','llms.txt']:
    if not Path(req).exists(): fail('expected V3.3 file missing: '+req)
# Install new pages.
mapfiles={
 'sektorler__dis-estetik-wellness.html':'sektorler/dis-estetik-wellness.html',
 'araclar__gelir-kacagi-hesaplayici.html':'araclar/gelir-kacagi-hesaplayici.html',
 'araclar__surec-hazirlik-skoru.html':'araclar/surec-hazirlik-skoru.html',
 'araclar__otomasyon-deger-hesaplayici.html':'araclar/otomasyon-deger-hesaplayici.html',
 'cozumler__musteri-talebi-surec-analizi.html':'cozumler/musteri-talebi-surec-analizi.html',
 'cozumler__site-katalog-uyumlulugu.html':'cozumler/site-katalog-uyumlulugu.html'}
for src,dst in mapfiles.items():
    d=Path(dst); d.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(PAY/'new'/src,d)
# Revenue page: inject customer-language tools before final CTA/band or before </main>.
p=Path('urunler/revenueos.html'); s=read(p)
marker='D02-TOOLS-START'
block='''<!-- D02-TOOLS-START --><section class="section"><div class="container"><div class="section-head"><div><div class="kicker">Ücretsiz araçlar</div><h2>Önce kendi baz çizginizi görün.</h2></div><p>İki araç da sonuç garantisi vermez; yalnız görünür varsayımlar ve süreç hazırlığı üzerinden senaryo üretir.</p></div><div class="grid grid-3"><article class="card"><h3>Müşteri Talebi Kayıp Hesaplayıcısı</h3><p>Aylık talep, ortalama değer, mevcut satış oranı ve unutulan talep varsayımını görünür yapar.</p><a class="more" href="../araclar/gelir-kacagi-hesaplayici.html">Hesaplayıcıyı aç</a></article><article class="card"><h3>Süreç Hazırlık Skoru</h3><p>Veri, kaynak, insan onayı ve ölçüm açısından ilk uygulama hazırlığını 8 soruda kontrol eder.</p><a class="more" href="../araclar/surec-hazirlik-skoru.html">Skoru aç</a></article><article class="card"><h3>24 Saat Süreç Analizi</h3><p>Talep hattındaki kayıp noktalarını, insan kapılarını ve en küçük güvenli başlangıcı tek dosyada çıkarır.</p><a class="more" href="../cozumler/musteri-talebi-surec-analizi.html">Analizi incele</a></article></div></div></section><!-- D02-TOOLS-END -->'''
if marker not in s:
    if '</main>' not in s: fail('revenueos </main> anchor missing')
    s=s.replace('</main>',block+'</main>',1); write(p,s)
# Other product pages: only if present, append non-jargon customer link.
for fn,block in [
('urunler/agentready.html','''<!-- D02-AGENTREADY-START --><section class="section"><div class="container"><div class="featured"><div><div class="kicker">Site ve katalog hazırlığı</div><h2>Ürün ve hizmet gerçekleriniz ne kadar doğrulanabilir?</h2><p class="lead">7 kategoride eksik yapılandırılmış veri, fiyat/stok, politika ve işlem yolunu görünür yapın.</p></div><div class="price-box"><a class="btn btn-primary" href="../cozumler/site-katalog-uyumlulugu.html">Hazırlık analizini incele</a></div></div></div></section><!-- D02-AGENTREADY-END -->'''),
('urunler/magnetflow.html','''<!-- D02-MAGNETFLOW-START --><section class="section"><div class="container"><div class="section-head"><div><div class="kicker">Etkileşimli mini araçlar</div><h2>Teklifi statik metinden karar deneyimine çevirin.</h2></div></div><div class="grid grid-3"><article class="card"><h3>Süreç Hazırlık Skoru</h3><a class="more" href="../araclar/surec-hazirlik-skoru.html">Aracı aç</a></article><article class="card"><h3>Operasyon Değeri Hesaplayıcısı</h3><a class="more" href="../araclar/otomasyon-deger-hesaplayici.html">Aracı aç</a></article></div></div></section><!-- D02-MAGNETFLOW-END -->''')]:
    p=Path(fn)
    if p.exists():
        s=read(p)
        if block.split('<!--')[1].split('-->')[0] not in s:
            if '</main>' not in s: fail(fn+' </main> anchor missing')
            write(p,s.replace('</main>',block+'</main>',1))
# Sector directory: inject a focused card while keeping every sector active.
p=Path('sektorler.html'); s=read(p)
sector='''<!-- D02-DENTAL-START --><section class="section-tight"><div class="container"><div class="featured"><div><div class="kicker">Sektör uygulaması</div><h2>Diş, Estetik &amp; Wellness</h2><p class="lead">Randevu, onaylı sık sorulan sorular, talep nitelendirme ve insan devri; tıbbi tavsiye vermeyen müşteri iletişim akışı.</p></div><a class="btn btn-primary" href="sektorler/dis-estetik-wellness.html">Çözümü incele</a></div></div></section><!-- D02-DENTAL-END -->'''
if 'D02-DENTAL-START' not in s:
    if '</main>' not in s: fail('sektorler </main> anchor missing')
    write(p,s.replace('</main>',sector+'</main>',1))
# Health page crosslink.
p=Path('sektorler/saglik.html')
if p.exists():
    s=read(p); link='''<!-- D02-HEALTH-LINK --><section class="section-tight"><div class="container"><div class="band"><div class="band-grid"><div><div class="kicker">Özel uygulama</div><h2>Diş, Estetik &amp; Wellness müşteri talebi akışını inceleyin.</h2></div><a class="btn btn-primary" href="dis-estetik-wellness.html">Detayları gör</a></div></div></div></section>'''
    if 'D02-HEALTH-LINK' not in s:
        if '</main>' not in s: fail('health </main> anchor missing')
        write(p,s.replace('</main>',link+'</main>',1))
# Sitemap: add six URLs, no duplicate.
p=Path('sitemap.xml'); s=read(p)
urls=['sektorler/dis-estetik-wellness.html','araclar/gelir-kacagi-hesaplayici.html','araclar/surec-hazirlik-skoru.html','araclar/otomasyon-deger-hesaplayici.html','cozumler/musteri-talebi-surec-analizi.html','cozumler/site-katalog-uyumlulugu.html']
if '</urlset>' not in s: fail('sitemap closing tag missing')
for u in urls:
    if u not in s:
        s=s.replace('</urlset>',f'<url><loc>https://synapseautomate.github.io/{u}</loc><lastmod>2026-08-05</lastmod><changefreq>weekly</changefreq><priority>0.8</priority></url>\n</urlset>')
write(p,s)
# llms.txt public knowledge profile, plain text only.
p=Path('llms.txt'); s=read(p)
if '## Day 2 public assets (2026-08-05)' not in s:
    s+='''\n\n## Day 2 public assets (2026-08-05)\n- Dental / aesthetic / wellness: https://synapseautomate.github.io/sektorler/dis-estetik-wellness.html\n- Customer request loss scenario calculator: https://synapseautomate.github.io/araclar/gelir-kacagi-hesaplayici.html\n- Process readiness score: https://synapseautomate.github.io/araclar/surec-hazirlik-skoru.html\n- 24-hour process analysis: https://synapseautomate.github.io/cozumler/musteri-talebi-surec-analizi.html\n- Site & catalog readiness analysis: https://synapseautomate.github.io/cozumler/site-katalog-uyumlulugu.html\n'''
write(p,s)
# Preserve D02 proof in repo, not public navigation.
proof=Path('D02'); proof.mkdir(exist_ok=True)
for f in (PAY/'D02').iterdir(): shutil.copy2(f,proof/f.name)
print('D02 PATCH APPLY: PASS')
