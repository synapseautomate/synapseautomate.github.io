#!/usr/bin/env python3
from pathlib import Path
import sys,re,csv,json
req=['sektorler/dis-estetik-wellness.html','araclar/gelir-kacagi-hesaplayici.html','araclar/surec-hazirlik-skoru.html','araclar/otomasyon-deger-hesaplayici.html','cozumler/musteri-talebi-surec-analizi.html','cozumler/site-katalog-uyumlulugu.html','D02/synthetic_cases.csv','D02/faq_30_demo_kb.csv','D02/intent_flows.json']
err=[]
for f in req:
    if not Path(f).is_file(): err.append('missing '+f)
for f in req[:6]:
    s=Path(f).read_text(encoding='utf-8') if Path(f).exists() else ''
    for must in ['Süreç Analizi İste','Synapse Automate']:
        if must not in s: err.append(f+' missing '+must)
    if '{{' in s or "'.join(" in s or 'roof_faq' in s or 'rev_faq' in s: err.append(f+' template artifact')
    if 'satış garantisi' in s.lower() and 'yok' not in s.lower() and 'değil' not in s.lower(): err.append(f+' unsafe sales guarantee context')
if Path('D02/synthetic_cases.csv').exists():
    with open('D02/synthetic_cases.csv',encoding='utf-8-sig') as fh:
        n=sum(1 for _ in csv.DictReader(fh))
    if n!=30: err.append(f'synthetic cases={n}, expected 30')
if Path('D02/faq_30_demo_kb.csv').exists():
    with open('D02/faq_30_demo_kb.csv',encoding='utf-8-sig') as fh:
        n=sum(1 for _ in csv.DictReader(fh))
    if n!=30: err.append(f'faq rows={n}, expected 30')
if Path('D02/intent_flows.json').exists():
    n=len(json.loads(Path('D02/intent_flows.json').read_text(encoding='utf-8')))
    if not 8<=n<=12: err.append(f'intent flows={n}, expected 8-12')
sm=Path('sitemap.xml').read_text(encoding='utf-8') if Path('sitemap.xml').exists() else ''
for f in req[:6]:
    if f not in sm: err.append('sitemap missing '+f)
# No raw PII-looking samples in D02. This intentionally catches common obvious formats only.
for f in Path('D02').glob('*'):
    if f.suffix.lower() in {'.md','.csv','.json','.txt'}:
        s=f.read_text(encoding='utf-8',errors='ignore')
        if re.search(r'\b\d{11}\b',s): err.append(f'possible raw national id in {f}')
if err:
    print('\n'.join('FAIL: '+x for x in err)); sys.exit(2)
print('D02 PATCH QA: PASS')
