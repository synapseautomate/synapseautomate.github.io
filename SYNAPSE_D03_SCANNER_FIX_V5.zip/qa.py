#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys

ROOT=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
page=ROOT/"araclar/site-ai-uyumluluk-taramasi.html"
js=ROOT/"assets/day3/scanner-v5.js"
errors=[]

def err(x): errors.append(x)

for p in (page,js):
    if not p.exists(): err("missing "+str(p.relative_to(ROOT)))

if not errors:
    h=page.read_text(encoding="utf-8")
    j=js.read_text(encoding="utf-8")
    for token in [
        "Ön kontrolü başlat",
        "/assets/day3/scanner-v5.js?v=20260807-1"
    ]:
        if token not in h: err("HTML missing "+token)

    if h.count("scanner-v5.js") != 1: err("scanner V5 must load exactly once")

    for token in [
        "cloneNode(true)",
        "stopImmediatePropagation",
        "button.insertAdjacentElement('afterend', out)",
        "Ön kontrol tamamlandı",
        "Hazırlık skoru:",
        "İçerik taranmadan puan verilmez",
        "out.scrollIntoView",
        "scan-v5-toast"
    ]:
        if token not in j: err("JS missing "+token)

    r=subprocess.run(["node","--check",str(js)],capture_output=True,text=True)
    if r.returncode: err("node syntax: "+r.stderr.strip())

if errors:
    print("SCANNER V5 QA: FAIL")
    for e in errors: print("-",e)
    raise SystemExit(1)

print("SCANNER V5 QA: PASS")
