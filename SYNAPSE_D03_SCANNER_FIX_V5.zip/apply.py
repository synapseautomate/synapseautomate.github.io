#!/usr/bin/env python3
from pathlib import Path
import re, shutil, sys

ROOT = Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
PKG = Path(__file__).resolve().parent
page = ROOT/"araclar/site-ai-uyumluluk-taramasi.html"

def fail(msg):
    print("SCANNER V5 APPLY: FAIL")
    print("-",msg)
    raise SystemExit(2)

if not page.exists():
    fail("scanner page missing")

src = PKG/"payload/assets/day3/scanner-v5.js"
dst = ROOT/"assets/day3/scanner-v5.js"
dst.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(src,dst)

s = page.read_text(encoding="utf-8")

# Give user correct static label even before JS executes.
s = re.sub(
    r'(<button[^>]*type=["\']submit["\'][^>]*>).*?(</button>)',
    r'\1Ön kontrolü başlat\2',
    s, count=1, flags=re.I|re.S
)

# Remove previous V4/V5 external references and add one unique V5 reference.
s = re.sub(r'<script[^>]+src=["\'][^"\']*scanner-v[45][^"\']*["\'][^>]*></script>', '', s, flags=re.I)
tag = '<script defer src="/assets/day3/scanner-v5.js?v=20260807-1"></script>'
if "</body>" not in s:
    fail("</body> missing")
s = s.replace("</body>", tag+"</body>", 1)

page.write_text(s, encoding="utf-8")
print("SCANNER V5 APPLY: PASS")
