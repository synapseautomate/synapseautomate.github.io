# Scanner V5

Kök UX düzeltmesi: eski event listener'ları form clone ile kaldırır; sonucu fiziksel olarak submit butonunun hemen altına taşır; toast + otomatik scroll + görünür 7 kategori sonucu üretir. İçerik crawl edilmeden skor uydurmaz.
