# D03 Discovery V3

- Stable URL: `kaynaklar.html`
- Menu label: `Ücretsiz AI Araçları`
- Page title: `Ücretsiz AI Araçları, Rehberler & Demolar`
- Visible homepage entry added
- Runtime guard ensures old templates also expose the link
