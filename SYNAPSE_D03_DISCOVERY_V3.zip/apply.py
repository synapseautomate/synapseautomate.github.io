#!/usr/bin/env python3
from pathlib import Path
import re, sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()

def fail(msg):
    print("D03 DISCOVERY V3 APPLY: FAIL")
    print("-", msg)
    raise SystemExit(2)

def get(rel):
    p = ROOT / rel
    if not p.exists():
        fail("missing required file: " + rel)
    return p, p.read_text(encoding="utf-8")

# 1) Rename customer-facing resource page while keeping stable URL.
p, s = get("kaynaklar.html")
s = re.sub(r"<title>.*?</title>",
           "<title>Ücretsiz AI Araçları, Rehberler &amp; Demolar | Synapse Automate</title>",
           s, count=1, flags=re.S)
s = s.replace("Kaynak Merkezi", "Ücretsiz AI Araçları")
s = s.replace("Önce görünür kanıt. Sonra otomasyon.", "Önce ölçün. Sonra otomasyon kararı verin.")
s = re.sub(r"<h1>.*?</h1>",
           "<h1>Ücretsiz AI Araçları, Rehberler &amp; Demolar</h1>",
           s, count=1, flags=re.S)
p.write_text(s, encoding="utf-8")

# 2) Add/rename link in both menu shells.
for p in ROOT.rglob("*.html"):
    rel = p.relative_to(ROOT).as_posix()
    if rel.startswith(".github/") or rel.startswith("D0") or rel.startswith("_site/"):
        continue
    try:
        s = p.read_text(encoding="utf-8")
    except Exception:
        continue

    depth = len(p.relative_to(ROOT).parts) - 1
    pre = "../" * depth
    target = pre + "kaynaklar.html"

    for nav_class in ("nav-links", "navlinks"):
        m = re.search(r'<nav class="' + re.escape(nav_class) + r'"[^>]*>(.*?)</nav>', s, flags=re.S)
        if not m:
            continue
        body = m.group(1)

        # Rename existing href="...kaynaklar.html"
        body = re.sub(
            r'(<a[^>]+href="[^"]*kaynaklar\.html"[^>]*>).*?(</a>)',
            r'\1Ücretsiz AI Araçları\2',
            body, flags=re.I|re.S
        )

        # Insert after Sektörler if missing.
        if "kaynaklar.html" not in body:
            link = '<a href="' + target + '" class="nav-free-tools">Ücretsiz AI Araçları</a>'
            body2, n = re.subn(
                r'(<a[^>]+href="[^"]*sektorler\.html"[^>]*>.*?</a>)',
                r'\1' + link,
                body, count=1, flags=re.I|re.S
            )
            body = body2 if n else body + link

        s = s[:m.start(1)] + body + s[m.end(1):]

    s = s.replace(">Kaynak Merkezi</a>", ">Ücretsiz AI Araçları</a>")
    p.write_text(s, encoding="utf-8")

# 3) Homepage visible entry independent of hamburger.
p, s = get("index.html")
marker = "D03-FREE-AI-TOOLS-DISCOVERY"
if marker not in s:
    block = (
        '<!-- ' + marker + ' -->'
        '<section class="section-tight free-ai-tools-discovery" aria-labelledby="free-ai-tools-title">'
        '<div class="container"><div class="featured"><div>'
        '<div class="kicker">Ücretsiz AI Araçları</div>'
        '<h2 id="free-ai-tools-title">Önce ölçün. Sonra otomasyon kararı verin.</h2>'
        '<p class="lead">Talep kaybı, süreç hazırlığı, site ve katalog doğrulanabilirliği, finans güven sınırları ve insan onayı için ücretsiz araçları ve kontrollü demoları kullanın.</p>'
        '</div><a class="btn btn-primary" href="kaynaklar.html">Ücretsiz Araçları Keşfet</a>'
        '</div></div></section>'
    )
    if "</main>" not in s:
        fail("index.html has no </main> anchor")
    s = s.replace("</main>", block + "</main>", 1)
p.write_text(s, encoding="utf-8")

# 4) Runtime menu guard for stale templates.
js_path = ROOT / "assets/app-v33.js"
if js_path.exists():
    js = js_path.read_text(encoding="utf-8")
    if "D03_FREE_AI_TOOLS_NAV_GUARD" not in js:
        guard = """
/* D03_FREE_AI_TOOLS_NAV_GUARD */
(() => {
  const ensureFreeToolsLink = () => {
    document.querySelectorAll('.nav-links, .navlinks').forEach(nav => {
      let link = Array.from(nav.querySelectorAll('a')).find(a => /kaynaklar\.html(?:$|[?#])/.test(a.getAttribute('href') || ''));
      if (link) {
        link.textContent = 'Ücretsiz AI Araçları';
        link.classList.add('nav-free-tools');
        return;
      }
      link = document.createElement('a');
      link.href = '/kaynaklar.html';
      link.textContent = 'Ücretsiz AI Araçları';
      link.className = 'nav-free-tools';
      const sector = Array.from(nav.querySelectorAll('a')).find(a => /sektorler\.html/.test(a.getAttribute('href') || ''));
      if (sector && sector.nextSibling) nav.insertBefore(link, sector.nextSibling);
      else nav.appendChild(link);
    });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ensureFreeToolsLink);
  else ensureFreeToolsLink();
})();
"""
        js += guard
        js_path.write_text(js, encoding="utf-8")

# 5) Visual emphasis.
css_path = ROOT / "assets/styles-v33.css"
if css_path.exists():
    css = css_path.read_text(encoding="utf-8")
    if "D03-FREE-AI-TOOLS-STYLE" not in css:
        css += """
/* D03-FREE-AI-TOOLS-STYLE */
.nav-links .nav-free-tools,.navlinks .nav-free-tools{color:#73eadc;font-weight:800}
.free-ai-tools-discovery .featured{position:relative;overflow:hidden}
.free-ai-tools-discovery .featured::after{content:"";position:absolute;width:240px;height:240px;right:-80px;top:-100px;border-radius:50%;background:radial-gradient(circle,rgba(49,220,198,.18),rgba(49,220,198,0) 70%);pointer-events:none}
"""
        css_path.write_text(css, encoding="utf-8")

day3_css = ROOT / "assets/day3/day3.css"
if day3_css.exists():
    css = day3_css.read_text(encoding="utf-8")
    if "D03-FREE-AI-TOOLS-DAY3-STYLE" not in css:
        css += "\n/* D03-FREE-AI-TOOLS-DAY3-STYLE */\n.navlinks .nav-free-tools{color:var(--teal);font-weight:900}\n"
        day3_css.write_text(css, encoding="utf-8")

print("D03 DISCOVERY V3 APPLY: PASS")
