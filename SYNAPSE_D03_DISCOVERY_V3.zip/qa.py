#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
errors = []

def err(msg):
    errors.append(msg)

for rel in ["index.html","kaynaklar.html","assets/styles-v33.css","assets/app-v33.js"]:
    if not (ROOT/rel).exists():
        err("missing required file: " + rel)

if not errors:
    idx = (ROOT/"index.html").read_text(encoding="utf-8")
    hub = (ROOT/"kaynaklar.html").read_text(encoding="utf-8")
    app = (ROOT/"assets/app-v33.js").read_text(encoding="utf-8")
    css = (ROOT/"assets/styles-v33.css").read_text(encoding="utf-8")

    tests = [
        ("homepage discovery", "D03-FREE-AI-TOOLS-DISCOVERY" in idx),
        ("homepage CTA", "Ücretsiz Araçları Keşfet" in idx),
        ("hub title", "Ücretsiz AI Araçları" in hub and "Rehberler" in hub and "Demolar" in hub),
        ("runtime menu guard", "D03_FREE_AI_TOOLS_NAV_GUARD" in app),
        ("menu styling", "D03-FREE-AI-TOOLS-STYLE" in css),
    ]
    for name, ok in tests:
        if not ok:
            err(name)

    for token in [
        "Müşteri Talebi Kayıp Hesaplayıcısı",
        "Süreç Hazırlık Skoru",
        "Finans Süreç Kontrol Listesi",
        "Etkileşimli Teklif Şablonu",
        "24 Saat Süreç Analizi",
        "VELA Kontrollü Saha Akışı",
        "AI Otomasyon Kanıt Metodolojisi"
    ]:
        if token not in hub:
            err("hub missing required asset: " + token)

if errors:
    print("D03 DISCOVERY V3 QA: FAIL")
    for e in errors:
        print("-", e)
    raise SystemExit(1)

print("D03 DISCOVERY V3 QA: PASS")
